# web — 프론트엔드

`app/` 의 FastAPI 를 쓰는 화면 두 개. 앱을 나눈 이유는 배포 위치가 다르기 때문이다.

| 폴더 | 누가 보나 | 어디서 도나 | 포트(개발) |
|---|---|---|---|
| `web/admin` | 직원 | 복지관 PC 브라우저 | 5173 |
| `web/kiosk` | 어르신 | 로봇의 7인치 터치스크린 (Jetson 크로미움) | 5174 |

공용 코드는 일부러 두지 않았다. 키오스크는 Jetson 에서 혼자 떠야 하므로
번들에 관리자 코드가 섞이지 않는 편이 낫다. 대신 `src/types.ts` 가 양쪽에 있으니
`app/schemas.py` 를 고치면 **두 파일을 같이 고쳐야 한다.**

스택은 `CLAUDE.md` 대로 React 18 + TypeScript + Vite,
실내 지도는 Leaflet `CRS.Simple` (위경도 아님).

---

## 실행

```powershell
# 1) API 먼저
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload

# 2) 관리자
cd web\admin
copy .env.example .env
npm install
npm run dev          # http://localhost:5173

# 3) 키오스크 (다른 터미널)
cd web\kiosk
copy .env.example .env
npm install
npm run dev          # http://localhost:5174
```

### CORS 를 먼저 열어야 한다

`app/config.py` 의 기본값에 5174 가 없다. 프로젝트 루트 `.env` 에 이 줄을 넣는다.

```
CORS_ORIGINS=["http://localhost:5173","http://localhost:5174"]
```

### 로그인 계정

시드에 관리자 계정이 없다 (일부러 안 넣었다). 먼저 만든다.

```powershell
.\.venv\Scripts\python.exe tools\create_admin.py
```

---

## 백엔드 없이 눌러보기 (프로토타입)

발표·회의용. API 도 로봇도 없이 화면 흐름만 보여준다.

```powershell
node web\prototype\build.mjs
# -> web\prototype\dist\prototype.html  (파일 하나, 더블클릭하면 열린다)
```

`VITE_MOCK=on` 으로 빌드하면 `src/demo/mock.ts` 가 `window.fetch` 를 가로채
메모리 안의 가짜 DB로 응답한다. 로그인·목적지 추가/수정/정렬·원격 취소·
키오스크 안내 흐름이 **실제로 동작한다** (새로고침하면 초기화된다).

- 관리자 로그인: `admin@demo.org` (비밀번호는 아무거나) — `staff@demo.org`,
  `view@demo.org` 로 바꿔 넣으면 권한별 화면 차이를 볼 수 있다.
- 키오스크는 `.env.demo` 가 `VITE_DEMO=on` 이라 6초 뒤 도착으로 넘어간다.

**이 코드는 시연 전용이다.** 일반 빌드(`npm run build`)에는
`src/demo/` 가 트리셰이킹으로 통째로 빠진다 — 번들을 열어 확인할 수 있다.

---

## 관리자 (`web/admin`)

| 화면 | 기능 이름표 | 상태 |
|---|---|---|
| 로그인 | `직원-로그인` | 서버 API 사용 |
| 대시보드 | `직원-로봇상태` `직원-대리요청` `직원-원격취소` | 서버 API 사용 |
| 〃 지도 위 로봇 위치 | `직원-실시간위치` | **폴링으로 대체** — 좌표 API 없음 |
| 안내 이력 / 상세 | `직원-안내이력` `직원-안내상세` | 서버 API 사용 |
| 안내 통계 | `직원-안내통계` | **프론트 집계** — 최근 N건만 |
| 장애물 다발 지점 | `직원-히트맵` | **프론트 집계** — 안내 N건의 사건을 격자로 |
| 목적지 관리 | `직원-목적지편집` `직원-음성문구편집` | 서버 API 사용 (드래그 정렬 포함) |
| 구역 관리 | `직원-구역편집` | **조회만** — 편집 API 없음 |
| 지도 관리 | `직원-지도관리` | **조회만** — 업로드 API 없음 |
| 계정 관리 | `직원-계정관리` `시스템-권한관리` | 서버 API 사용 (admin 전용) |

### 서버 API 가 생기면 걷어낼 임시 코드

프론트에서 대신 계산하고 있는 곳은 파일 맨 위 주석에 이유를 적어뒀다.

- `src/lib/usePolling.ts` — WebSocket 대신 REST 를 주기 폴링. `직원-실시간위치` 가 생기면 이 훅을 쓰는 화면만 교체.
- `src/pages/Stats.tsx` — `GET /trips` 를 브라우저에서 집계. `GET /stats/trips` 가 생기면 집계 부분 삭제.
- `src/pages/Heatmap.tsx` — 안내 N건의 `GET /trips/{id}/events` 를 순차 호출. `trip_event.geom` PostGIS 집계 API 가 생기면 교체.
- `src/pages/Zones.tsx`, `src/pages/Maps.tsx` — `NotReady` 배너로 필요한 엔드포인트를 화면에 적어뒀다.

### 지도 배경

`map.pgm_uri` 가 `s3://` 라 브라우저가 직접 못 읽는다.
PGM 을 PNG 로 변환해 `{base}/{map_id}.png` 로 서빙하고 `.env` 의
`VITE_MAP_IMAGE_BASE` 를 채우면 모든 지도 화면 배경으로 깔린다.
지금은 격자 위에 목적지·구역만 그린다.

---

## 키오스크 (`web/kiosk`)

`docs/SCREEN-FLOW.md` 의 흐름을 그대로 옮겼다.

```
대기 → 목적지 선택 → (확인) → 안내 중 → 도착 → (만족도) → 대기
                          ↘ 잠시만요 / 취소되었습니다 ↗
```

화면은 상태를 지어내지 않는다. **`trip.status` 가 유일한 진실**이고,
`GET /trips?robot_id=` 를 폴링해서 화면을 바꾼다.

### `[미결정]` 은 전부 설정으로 뺐다

회의에서 정해지면 `.env` 만 고치면 된다. 화면 코드는 건드리지 않는다.

| .env | 미결정 항목 | 값 |
|---|---|---|
| `VITE_CONFIRM_STEP` | ① 확인 화면을 넣을 것인가 | `on` / `off` |
| `VITE_FEEDBACK` | ② 만족도를 받을 것인가, 몇 단계인가 | `off` / `3` / `5` |
| `VITE_ARRIVAL` | ③ 도착 판정을 누가 하는가 | `robot` / `staff` |
| `VITE_VOICE` | 음성 안내 사용 여부 | `on` / `off` |

만족도는 서버에 `feedback` 테이블이 없어서 지금은 브라우저(localStorage)에만 쌓인다.
`src/lib/feedback.ts` 의 `flush()` 를 채우면 서버로 올라간다.

### 남은 거리를 표시하지 않는 이유

`사용자-진행상황` 에 필요한 로봇 좌표 API 가 아직 없다.
숫자를 지어내면 어르신이 그 숫자를 믿는다. 그래서 불확정 진행 막대와
경과 시간만 보여준다. `로봇-위치보고` 가 생기면 `src/screens/Navigating.tsx`
의 막대만 실제 진행률로 바꾸면 된다.

### 데모 모드

로봇 없이 발표·시연할 때 쓴다.

```
VITE_DEMO=on
```

trip 을 `is_simulated=true` 로 만들고 상태 전환(`navigating` → `arrived`)을
화면이 직접 `PATCH` 한다. 시뮬레이션 표시가 붙으므로 통계에서 빠진다.

### Jetson 배포

```bash
npm run build                     # dist/ 생성 (base='./' 라 어디에 둬도 열린다)
chromium-browser --kiosk --app=file:///opt/sbr-kiosk/dist/index.html
# 또는 nginx 로 dist/ 서빙 후 --app=http://localhost/
```

---

## 커밋 메시지

`CLAUDE.md` 규칙대로 기능 이름표를 적는다.

```
feat(직원-목적지편집): 드래그 정렬 UI 추가
feat(사용자-안내취소): 취소 버튼을 화면 1/3 크기로
```
