/**
 * 클릭 가능한 프로토타입 만들기.
 *
 *   node web/prototype/build.mjs
 *   -> web/prototype/dist/prototype.html  (파일 하나, 외부 요청 0개)
 *
 * admin / kiosk 를 각각 VITE_MOCK=on 으로 빌드해서 가짜 API를 넣고,
 * JS·CSS 를 한 파일로 합친 뒤 shell.html 안에 base64 로 심는다.
 * 백엔드도 로봇도 없이 브라우저에서 바로 열린다. **시연 전용이다.**
 */
import { execSync } from 'node:child_process'
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const web = join(here, '..')

function buildApp(name) {
  console.log(`· ${name} 데모 빌드`)
  execSync('npx vite build --outDir dist-demo --mode demo', {
    cwd: join(web, name),
    stdio: 'inherit',
    env: { ...process.env, VITE_MOCK: 'on' },
  })
}

function inlineApp(name, title) {
  const assets = join(web, name, 'dist-demo', 'assets')
  const files = readdirSync(assets)
  const js = files.filter((f) => f.endsWith('.js')).map((f) => readFileSync(join(assets, f), 'utf8'))
  const css = files.filter((f) => f.endsWith('.css')).map((f) => readFileSync(join(assets, f), 'utf8'))
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
<style>${css.join('\n')}</style>
</head><body><div id="root"></div>
<script type="module">${js.join('\n;\n')}</script>
</body></html>`
}

buildApp('admin')
buildApp('kiosk')

const payload = JSON.stringify({
  admin: Buffer.from(inlineApp('admin', 'Subject R 관리자'), 'utf8').toString('base64'),
  kiosk: Buffer.from(inlineApp('kiosk', '안내 로봇'), 'utf8').toString('base64'),
})

const shell = readFileSync(join(here, 'shell.html'), 'utf8')
// shell.html 은 Artifact 로 올릴 때를 대비해 <head> 없이 조각으로 두었다.
// 파일로 열 때는 최소한의 문서 껍데기를 씌운다.
const page = shell.includes('<!doctype')
  ? shell.replace('__PAYLOAD__', payload)
  : `<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head><body>
${shell.replace('__PAYLOAD__', payload)}
</body></html>`

mkdirSync(join(here, 'dist'), { recursive: true })
const out = join(here, 'dist', 'prototype.html')
writeFileSync(out, page)
console.log(`\n${out}  (${Math.round(Buffer.byteLength(page) / 1024)} KB)`)
