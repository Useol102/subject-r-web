import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'

// 키오스크는 손가락으로만 쓴다. 확대/우클릭/드래그 선택을 막아 오조작을 줄인다.
document.addEventListener('contextmenu', (e) => e.preventDefault())
document.addEventListener('gesturestart', (e) => e.preventDefault())

async function boot() {
  // 데모 빌드(VITE_MOCK=on)에서만 가짜 API를 붙인다.
  if (import.meta.env.VITE_MOCK === 'on') {
    const { installMock } = await import('./demo/mock')
    installMock()
  }
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
}

void boot()
