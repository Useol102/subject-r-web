/**
 * 데모용 가짜 API (키오스크).
 *
 * `VITE_MOCK=on` 으로 빌드할 때만 들어간다. 로봇도 서버도 없이
 * 목적지 선택 → 안내 → 도착 → 만족도 흐름을 그대로 굴린다.
 */
import type { FloorMapMeta, Poi, Robot, Trip, TripStatus } from '../types'

const nowIso = () => new Date().toISOString()

const MAPS: FloorMapMeta[] = [
  { id: 1, floor: 1, version: 2, name: '1층 데모 지도', is_active: true },
]

const ROBOT: Robot = {
  id: 1, uuid: 'a1b2c3d4-0000-4000-8000-000000000001', serial: 'SBR-0001',
  name: '토리', model: 'jetson-orin-nano-4wd', current_map_id: 1,
  status: 'idle', battery_pct: 74, last_seen_at: nowIso(),
}

type Seed = [string, string, string, Poi['category'], number, number, string | null, boolean]
const SEED: Seed[] = [
  ['ENTRANCE_1F', '정문 출입구', '출입구', 'entrance', 2.0, 0.5, '정문에 도착했습니다.', true],
  ['LOBBY_1F', '1층 로비', '로비', 'lobby', 5.0, 3.0, '로비에 도착했습니다.', true],
  ['RESTROOM_1F', '1층 화장실', '화장실', 'restroom', 12.0, 4.0, '화장실 앞에 도착했습니다.', true],
  ['THERAPY_1F', '물리치료실', '물리치료', 'therapy_room', 18.0, 7.5, '물리치료실에 도착했습니다.', true],
  ['PROGRAM_1F', '프로그램실', '프로그램', 'program_room', 22.0, 2.0, '프로그램실에 도착했습니다.', true],
  ['ELEV_1F', '1층 엘리베이터', '엘리베이터', 'elevator', 15.0, -2.0, '엘리베이터 앞에 도착했습니다.', true],
  ['CAFE_1F', '1층 식당', '식당', 'cafeteria', 8.0, 8.5, '식당에 도착했습니다.', true],
  ['WAIT_1F', '대기 의자', '대기실', 'waiting_area', 6.5, -3.5, '대기 공간입니다. 편히 앉아 계세요.', true],
  ['STAIRS_1F', '1층 계단', '계단', 'stairs', 16.5, -4.0, null, false],
]

const POIS: Poi[] = SEED.map(([code, ko, short, cat, x, y, voice, wc], i) => ({
  id: i + 1, code, name_ko: ko, label: short, category: cat, x, y,
  approach_yaw: null, voice_script: voice, wheelchair_accessible: wc,
  display_order: i + 1,
}))

const TRIPS: Trip[] = []
let seq = 500

const ok = (body: unknown, status = 200) =>
  new Response(status === 204 ? null : JSON.stringify(body), {
    status, headers: { 'Content-Type': 'application/json' },
  })
const err = (status: number, detail: string) =>
  new Response(JSON.stringify({ detail }), {
    status, headers: { 'Content-Type': 'application/json' },
  })

function handle(method: string, path: string, q: URLSearchParams, body: any): Response {
  if (path === '/maps') return ok(MAPS)
  if (path === '/robots') return ok([ROBOT])
  if (/^\/maps\/\d+\/pois$/.test(path)) return ok(POIS)

  if (path === '/trips') {
    if (method === 'GET') {
      return ok([...TRIPS].reverse().slice(0, Number(q.get('limit') ?? 5)))
    }
    if (method === 'POST') {
      if (body.mode === 'guide' && !body.dest_poi_id)
        return err(400, 'guide 모드에는 dest_poi_id 가 필요하다')
      const dest = POIS.find((p) => p.id === body.dest_poi_id)
      const t: Trip = {
        id: ++seq, uuid: `${seq}-demo`, robot_id: 1, map_id: 1, status: 'requested',
        dest_poi_id: body.dest_poi_id ?? null, origin_poi_id: null,
        requested_at: nowIso(), started_at: null, ended_at: null,
        planned_distance_m: dest ? Math.round(Math.hypot(dest.x - 5, dest.y - 3) * 10) / 10 : null,
        actual_distance_m: null, abort_reason: null,
      }
      TRIPS.push(t)
      ROBOT.status = 'driving'
      return ok(t, 201)
    }
  }

  const r = /^\/trips\/(\d+)$/.exec(path)
  if (r && method === 'PATCH') {
    const t = TRIPS.find((x) => x.id === Number(r[1]))
    if (!t) return err(404, `trip ${r[1]} 없음`)
    if (body.status) {
      t.status = body.status as TripStatus
      if (body.status === 'navigating' && !t.started_at) t.started_at = nowIso()
      if (['arrived', 'completed', 'canceled', 'failed'].includes(body.status)) {
        t.ended_at = t.ended_at ?? nowIso()
        ROBOT.status = 'idle'
      }
    }
    if (body.abort_reason !== undefined) t.abort_reason = body.abort_reason
    return ok(t)
  }
  if (/^\/trips\/\d+\/events$/.test(path)) return ok({ id: 1 }, 201)

  return err(404, `데모 서버에 없는 경로다: ${method} ${path}`)
}

export function installMock(): void {
  const real = window.fetch.bind(window)
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input
      : input instanceof URL ? input.href : input.url
    // about:srcdoc 처럼 기준 주소가 없는 곳에서도 파싱되도록 가짜 base 를 준다.
    let u: URL
    try { u = new URL(url, 'http://demo.local') } catch { return real(input as RequestInfo, init) }

    const method = (init?.method ?? 'GET').toUpperCase()
    let body: any = undefined
    if (init?.body && typeof init.body === 'string') {
      try { body = JSON.parse(init.body) } catch { body = undefined }
    }
    await new Promise((res) => setTimeout(res, 80 + Math.random() * 90))
    return handle(method, u.pathname, u.searchParams, body)
  }
}
