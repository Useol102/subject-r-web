/**
 * 어르신 화면 상태 기계.
 *
 * docs/SCREEN-FLOW.md 의 흐름을 그대로 옮긴 것이다.
 *
 *   idle → list → (confirm) → navigating → arrived → (feedback) → idle
 *                     ↑            ↓ paused/failed
 *                     └─ canceled ← trouble
 *
 * trip.status 를 폴링해서 화면을 바꾼다. 화면이 상태를 지어내지 않는다 —
 * 서버의 trip.status 가 유일한 진실이다. (데모 모드만 예외)
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { config } from './config'
import { api } from './lib/api'
import { saveFeedback } from './lib/feedback'
import { speak, stopSpeaking } from './lib/speech'
import { Bar } from './components/Bar'
import { Idle } from './screens/Idle'
import { DestinationList } from './screens/DestinationList'
import { Confirm } from './screens/Confirm'
import { Navigating } from './screens/Navigating'
import { Trouble } from './screens/Trouble'
import { Arrived } from './screens/Arrived'
import { Canceled } from './screens/Canceled'
import { Feedback } from './screens/Feedback'
import type { Poi, Robot, Trip } from './types'

type Phase =
  | 'boot' | 'fatal' | 'idle' | 'list' | 'confirm'
  | 'navigating' | 'paused' | 'failed' | 'arrived' | 'feedback' | 'canceled'

const LIVE: Trip['status'][] = ['requested', 'navigating', 'paused']

export default function App() {
  const [phase, setPhase] = useState<Phase>('boot')
  const [fatal, setFatal] = useState<string | null>(null)
  const [robot, setRobot] = useState<Robot | null>(null)
  const [, setMapId] = useState<number | null>(null)
  const [pois, setPois] = useState<Poi[]>([])
  const [picked, setPicked] = useState<Poi | null>(null)
  const [trip, setTrip] = useState<Trip | null>(null)
  const [starting, setStarting] = useState(false)
  const [offline, setOffline] = useState(false)

  const tripIdRef = useRef<number | null>(null)
  const demoTimers = useRef<number[]>([])

  const clearDemo = () => {
    demoTimers.current.forEach((t) => window.clearTimeout(t))
    demoTimers.current = []
  }

  // ------------------------------------------------------------ 부팅
  useEffect(() => {
    let alive = true
    const boot = async () => {
      try {
        const robots = await api.listRobots()
        const r = config.robotId
          ? robots.find((x) => x.id === config.robotId) ?? null
          : robots[0] ?? null
        if (!r) throw new Error('등록된 로봇이 없습니다')

        let mid = config.mapId ?? r.current_map_id
        if (!mid) {
          const maps = await api.listMaps()
          mid = maps[0]?.id ?? null
        }
        if (!mid) throw new Error('활성 지도가 없습니다')

        const ps = await api.listPois(mid)
        if (!alive) return
        setRobot(r)
        setMapId(mid)
        setPois([...ps].sort((a, b) => a.display_order - b.display_order))
        setPhase('idle')
      } catch (e) {
        if (!alive) return
        setFatal(e instanceof Error ? e.message : String(e))
        setPhase('fatal')
      }
    }
    void boot()
    return () => { alive = false }
  }, [])

  // ------------------------------------------------------------ 상태 폴링
  useEffect(() => {
    if (!robot || !['navigating', 'paused'].includes(phase)) return
    let alive = true

    const tick = async () => {
      try {
        const list = await api.listTrips(robot.id, 5)
        if (!alive) return
        setOffline(false)
        const id = tripIdRef.current
        const t = id ? list.find((x) => x.id === id) : list.find((x) => LIVE.includes(x.status))
        if (!t) return
        setTrip(t)
        switch (t.status) {
          case 'requested':
          case 'navigating': setPhase('navigating'); break
          case 'paused':     setPhase('paused'); break
          case 'arrived':
          case 'completed':  setPhase('arrived'); break
          case 'canceled':   setPhase('canceled'); break
          case 'failed':     setPhase('failed'); break
        }
      } catch {
        if (alive) setOffline(true)
      }
    }

    void tick()
    const timer = window.setInterval(tick, config.pollMs)
    return () => { alive = false; window.clearInterval(timer) }
  }, [robot, phase])

  // ------------------------------------------------------------ 자동 복귀
  // 아무도 안 만지고 목록/확인 화면에 머무르면 대기 화면으로 돌아간다.
  useEffect(() => {
    if (phase !== 'list' && phase !== 'confirm') return
    let timer = window.setTimeout(() => setPhase('idle'), config.idleSec * 1000)
    const reset = () => {
      window.clearTimeout(timer)
      timer = window.setTimeout(() => setPhase('idle'), config.idleSec * 1000)
    }
    window.addEventListener('pointerdown', reset)
    return () => { window.clearTimeout(timer); window.removeEventListener('pointerdown', reset) }
  }, [phase])

  const goIdle = useCallback(() => {
    clearDemo()
    stopSpeaking()
    tripIdRef.current = null
    setTrip(null)
    setPicked(null)
    setPhase('idle')
  }, [])

  // ------------------------------------------------------------ 안내 시작
  const start = useCallback(async (poi: Poi) => {
    if (!robot) return
    setStarting(true)
    try {
      const t = await api.createTrip({
        robot_id: robot.id,
        mode: 'guide',
        dest_poi_id: poi.id,
        requested_by: 'kiosk',
        is_simulated: config.demo,
      })
      tripIdRef.current = t.id
      setTrip(t)
      setPhase('navigating')
      speak(`${poi.name_ko}으로 안내하겠습니다. 따라와 주세요.`)

      // 데모: 로봇이 없으므로 화면이 직접 상태를 밀어준다.
      // is_simulated=true 로 만들었으니 통계에서 빠진다.
      if (config.demo) {
        clearDemo()
        demoTimers.current.push(window.setTimeout(() => {
          void api.updateTrip(t.id, { status: 'navigating' }).catch(() => {})
        }, 1200))
        demoTimers.current.push(window.setTimeout(() => {
          void api.updateTrip(t.id, { status: 'arrived' }).catch(() => {})
        }, config.demoArriveSec * 1000))
      }
    } catch (e) {
      setFatal(e instanceof Error ? e.message : String(e))
      setPhase('fatal')
    } finally {
      setStarting(false)
    }
  }, [robot])

  const pick = useCallback((p: Poi) => {
    setPicked(p)
    if (config.confirmStep) setPhase('confirm')
    else void start(p)
  }, [start])

  const cancel = useCallback(async () => {
    clearDemo()
    stopSpeaking()
    const id = tripIdRef.current
    setPhase('canceled')
    if (id) {
      try {
        await api.updateTrip(id, { status: 'canceled', abort_reason: '사용자가 화면에서 취소' })
      } catch { /* 취소 통신 실패해도 화면은 되돌린다 */ }
    }
  }, [])

  /** [미결정 3] 도착 판정을 사람이 하는 설정일 때만 쓴다. */
  const markArrived = useCallback(async () => {
    const id = tripIdRef.current
    if (id) {
      try { await api.updateTrip(id, { status: 'arrived' }) } catch { /* ignore */ }
    }
    setPhase('arrived')
  }, [])

  const afterArrived = useCallback(() => {
    const id = tripIdRef.current
    // 만족도까지 끝나야 completed. 만족도를 안 받으면 도착 직후 완료 처리한다.
    if (config.feedback === 'off') {
      if (id) void api.updateTrip(id, { status: 'completed' }).catch(() => {})
      goIdle()
    } else {
      setPhase('feedback')
    }
  }, [goIdle])

  const submitFeedback = useCallback((score: number, scale: number) => {
    const id = tripIdRef.current
    if (id) {
      saveFeedback({ trip_id: id, score, scale, at: new Date().toISOString() })
      void api.updateTrip(id, { status: 'completed' }).catch(() => {})
    }
    goIdle()
  }, [goIdle])

  const skipFeedback = useCallback(() => {
    const id = tripIdRef.current
    if (id) void api.updateTrip(id, { status: 'completed' }).catch(() => {})
    goIdle()
  }, [goIdle])

  const visible = useMemo(() => pois, [pois])

  // ------------------------------------------------------------ 그리기
  if (phase === 'boot') {
    return (
      <div className="fatal">
        <div className="spinner" />
        <div className="lead">준비 중이에요</div>
      </div>
    )
  }

  if (phase === 'fatal') {
    return (
      <div className="fatal">
        <div className="result-ico result-ico--warn">🔧</div>
        <div className="h1">잠시 사용할 수 없어요</div>
        <div className="lead">직원에게 알려 주세요.</div>
        <div style={{ marginTop: '1rem', fontSize: '.85rem', color: '#8b98ab' }}>
          {fatal}<br />
          <code>{config.apiBase}</code>
        </div>
        <button className="big big--ghost" style={{ marginTop: '1rem' }}
                onClick={() => window.location.reload()}>
          다시 시도
        </button>
      </div>
    )
  }

  if (phase === 'idle') return <Idle robot={robot} onStart={() => setPhase('list')} />

  return (
    <>
      <Bar robot={robot} offline={offline} />
      {phase === 'list' ? (
        <DestinationList pois={visible} onPick={pick} onBack={goIdle} />
      ) : null}

      {phase === 'confirm' && picked ? (
        <Confirm poi={picked} busy={starting}
                 onYes={() => void start(picked)} onNo={() => setPhase('list')} />
      ) : null}

      {phase === 'navigating' && picked ? (
        <Navigating poi={picked} trip={trip}
                    onCancel={() => void cancel()} onArrived={() => void markArrived()} />
      ) : null}

      {phase === 'paused' ? (
        <Trouble poi={picked} kind="paused"
                 onRetry={() => setPhase('navigating')} onGiveUp={() => void cancel()} />
      ) : null}

      {phase === 'failed' ? (
        <Trouble poi={picked} kind="failed" onRetry={goIdle} onGiveUp={goIdle} />
      ) : null}

      {phase === 'arrived' && picked ? (
        <Arrived poi={picked} onNext={afterArrived} />
      ) : null}

      {phase === 'feedback' ? (
        <Feedback onPick={submitFeedback} onSkip={skipFeedback} />
      ) : null}

      {phase === 'canceled' ? <Canceled onNext={goIdle} /> : null}
    </>
  )
}
