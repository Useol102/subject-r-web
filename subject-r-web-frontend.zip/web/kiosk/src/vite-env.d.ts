/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE?: string
  readonly VITE_ROBOT_ID?: string
  readonly VITE_MAP_ID?: string
  readonly VITE_CONFIRM_STEP?: string
  readonly VITE_FEEDBACK?: string
  readonly VITE_ARRIVAL?: string
  readonly VITE_VOICE?: string
  readonly VITE_IDLE_SEC?: string
  readonly VITE_DEMO?: string
  readonly VITE_DEMO_ARRIVE_SEC?: string
  readonly VITE_POLL_MS?: string
  /** 'on' 이면 백엔드 없이 가짜 API로 돈다 (데모 전용) */
  readonly VITE_MOCK?: string
}
interface ImportMeta { readonly env: ImportMetaEnv }
