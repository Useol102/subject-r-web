/**
 * 키오스크용 API 클라이언트.
 *
 * 로그인이 없다. 어르신에게 로그인을 시킬 수 없으므로
 * `GET /maps/{id}/pois`, `POST /trips`, `PATCH /trips/{id}` 는 서버에서 열어뒀다.
 * (LAN 안에서만 접근 가능하다는 전제 — docs/FEATURES.md 참고)
 */
import { config } from '../config'
import type { FloorMapMeta, Poi, Robot, Trip, TripStatus } from '../types'

export class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
    this.name = 'ApiError'
  }
}

async function req<T>(path: string, init: RequestInit = {}): Promise<T> {
  const h = new Headers(init.headers)
  if (init.body && !h.has('Content-Type')) h.set('Content-Type', 'application/json')
  let res: Response
  try {
    res = await fetch(`${config.apiBase}${path}`, { ...init, headers: h })
  } catch {
    throw new ApiError(0, '서버에 연결할 수 없습니다')
  }
  if (!res.ok) {
    let detail = `${res.status}`
    try {
      const b = await res.json()
      if (typeof b?.detail === 'string') detail = b.detail
    } catch { /* ignore */ }
    throw new ApiError(res.status, detail)
  }
  if (res.status === 204) return undefined as T
  return (await res.json()) as T
}

export const api = {
  listMaps: () => req<FloorMapMeta[]>('/maps?active_only=true'),
  listRobots: () => req<Robot[]>('/robots'),
  listPois: (mapId: number) => req<Poi[]>(`/maps/${mapId}/pois`),
  listTrips: (robotId: number, limit = 5) =>
    req<Trip[]>(`/trips?robot_id=${robotId}&limit=${limit}`),
  createTrip: (body: {
    robot_id: number; mode: 'guide' | 'follow'
    dest_poi_id?: number | null; requested_by: 'kiosk'; is_simulated?: boolean
  }) => req<Trip>('/trips', { method: 'POST', body: JSON.stringify(body) }),
  updateTrip: (id: number, body: { status?: TripStatus; abort_reason?: string }) =>
    req<Trip>(`/trips/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  addEvent: (id: number, body: {
    event_type: string; severity?: number; payload?: Record<string, unknown>
  }) => req<unknown>(`/trips/${id}/events`, { method: 'POST', body: JSON.stringify(body) }),
}
