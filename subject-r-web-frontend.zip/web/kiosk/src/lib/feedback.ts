/**
 * `사용자-만족도` — 서버에 `feedback` 테이블이 아직 없다.
 * (회의에서 "만족도를 받을 것인가 / 몇 단계인가" 가 정해져야 만든다)
 *
 * 그동안 화면에서 받은 답은 브라우저에 쌓아만 둔다.
 * 테이블과 `POST /trips/{id}/feedback` 이 생기면 flush() 만 채우면 된다.
 */
const KEY = 'sbr.kiosk.feedback'

export interface FeedbackRow {
  trip_id: number
  score: number
  scale: number
  at: string   // ISO, UTC
}

export function saveFeedback(row: FeedbackRow): void {
  try {
    const cur = load()
    cur.push(row)
    localStorage.setItem(KEY, JSON.stringify(cur.slice(-500)))
  } catch { /* 저장 실패는 무시한다. 만족도 때문에 화면이 멈추면 안 된다 */ }
}

export function load(): FeedbackRow[] {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as FeedbackRow[]) : []
  } catch { return [] }
}

/** TODO(사용자-만족도): 서버 API가 생기면 여기서 밀어 올린다. */
export async function flush(): Promise<void> {
  return
}
