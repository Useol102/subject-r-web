/**
 * 음성 안내.  `사용자-도착안내` 는 화면과 음성을 동시에 내보내야 한다
 * (시력이나 청력 어느 한쪽이 약해도 전달되도록).
 *
 * Web Speech API 는 브라우저·기기마다 한국어 목소리 유무가 다르다.
 * 없으면 조용히 넘어간다 — 화면 글자만으로도 뜻이 통하게 만들어 뒀다.
 */
import { config } from '../config'

let warmed = false

export function speak(text: string | null | undefined): void {
  if (!config.voice || !text) return
  const synth = window.speechSynthesis
  if (!synth) return

  // 크로미움은 첫 발화 전에 목소리 목록이 비어 있을 때가 있다. 한 번 깨워둔다.
  if (!warmed) { synth.getVoices(); warmed = true }

  synth.cancel()
  const u = new SpeechSynthesisUtterance(text)
  u.lang = 'ko-KR'
  u.rate = 0.92   // 어르신 대상이라 조금 느리게
  u.pitch = 1
  const ko = synth.getVoices().find((v) => v.lang?.toLowerCase().startsWith('ko'))
  if (ko) u.voice = ko
  synth.speak(u)
}

export function stopSpeaking(): void {
  window.speechSynthesis?.cancel()
}
