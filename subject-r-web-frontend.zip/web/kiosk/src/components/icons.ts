import type { PoiCategory } from '../types'

/** 글자를 못 읽어도 알아볼 수 있게 큰 그림을 같이 쓴다. */
export const CATEGORY_ICON: Record<PoiCategory, string> = {
  entrance: '🚪', lobby: '🛋️', restroom: '🚻', elevator: '🛗', stairs: '🪜',
  therapy_room: '💊', program_room: '📚', office: '🗄️', cafeteria: '🍚',
  charging_station: '🔌', waiting_area: '🪑', other: '📍',
}
