import { useEffect, useState } from 'react'
import { config } from '../config'
import type { Robot } from '../types'

/** 상단 바. 어르신에게 필요한 정보는 거의 없다 — 로봇 이름과 시계만. */
export function Bar({ robot, offline }: { robot: Robot | null; offline?: boolean }) {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 10_000)
    return () => window.clearInterval(t)
  }, [])

  return (
    <div className="bar">
      <span style={{ fontSize: '1.2rem' }}>🤖</span>
      <span className="bar__name">{robot?.name ?? '안내 로봇'}</span>
      {config.demo ? <span className="bar__chip bar__chip--demo">데모</span> : null}
      {offline ? <span className="bar__chip">연결 확인 중</span> : null}
      <span className="bar__right">
        {now.toLocaleTimeString('ko-KR', {
          timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit', hour12: false,
        })}
      </span>
    </div>
  )
}
