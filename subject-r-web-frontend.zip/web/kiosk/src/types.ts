/** app/schemas.py 중 키오스크가 쓰는 것만. */
export type PoiCategory =
  | 'entrance' | 'lobby' | 'restroom' | 'elevator' | 'stairs'
  | 'therapy_room' | 'program_room' | 'office' | 'cafeteria'
  | 'charging_station' | 'waiting_area' | 'other'

export type TripStatus =
  | 'requested' | 'navigating' | 'paused' | 'arrived'
  | 'completed' | 'canceled' | 'failed'

export interface Poi {
  id: number
  code: string
  name_ko: string
  label: string
  category: PoiCategory
  x: number
  y: number
  approach_yaw: number | null
  voice_script: string | null
  wheelchair_accessible: boolean
  display_order: number
}

export interface Robot {
  id: number
  uuid: string
  serial: string
  name: string
  model: string | null
  current_map_id: number | null
  status: 'offline' | 'idle' | 'driving' | 'charging' | 'error' | 'estop'
  battery_pct: number | null
  last_seen_at: string | null
}

export interface FloorMapMeta {
  id: number
  floor: number
  version: number
  name: string | null
  is_active: boolean
}

export interface Trip {
  id: number
  uuid: string
  robot_id: number
  map_id: number
  status: TripStatus
  dest_poi_id: number | null
  origin_poi_id: number | null
  requested_at: string
  started_at: string | null
  ended_at: string | null
  planned_distance_m: number | null
  actual_distance_m: number | null
  abort_reason: string | null
}
