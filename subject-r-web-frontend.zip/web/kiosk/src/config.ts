/**
 * 화면 흐름의 [미결정] 항목을 전부 여기 모아둔다.
 *
 * docs/SCREEN-FLOW.md 의 `[미결정]` 1·2·3 번이 회의에서 정해지면
 * .env 값만 바꾸면 되고, 화면 코드는 건드리지 않는다.
 */
const env = import.meta.env

const on = (v: unknown, dflt: boolean) => {
  const s = String(v ?? '').toLowerCase()
  if (s === '') return dflt
  return s === 'on' || s === 'true' || s === '1' || s === 'yes'
}

export type FeedbackScale = 'off' | 3 | 5

const rawFeedback = String(env.VITE_FEEDBACK ?? '3').toLowerCase()
export const config = {
  apiBase: (String(env.VITE_API_BASE ?? 'http://localhost:8000')).replace(/\/$/, ''),
  robotId: Number(env.VITE_ROBOT_ID ?? '') || null,
  mapId: Number(env.VITE_MAP_ID ?? '') || null,

  /** [미결정 1] 확인 화면 */
  confirmStep: on(env.VITE_CONFIRM_STEP, true),

  /** [미결정 2] 만족도 — off / 3단계 / 5단계 */
  feedback: (rawFeedback === 'off' ? 'off'
    : rawFeedback === '5' ? 5 : 3) as FeedbackScale,

  /** [미결정 3] 도착 판정 주체 */
  arrivalBy: (String(env.VITE_ARRIVAL ?? 'robot') === 'staff' ? 'staff' : 'robot') as
    'robot' | 'staff',

  voice: on(env.VITE_VOICE, true),
  idleSec: Number(env.VITE_IDLE_SEC ?? 45),
  demo: on(env.VITE_DEMO, false),
  /** 데모 모드에서 도착으로 넘어가기까지의 시간(초) */
  demoArriveSec: Number(env.VITE_DEMO_ARRIVE_SEC ?? 9),
  pollMs: Number(env.VITE_POLL_MS ?? 1500),

  /** 한 화면에 넣는 목적지 버튼 수. 7인치에서 손가락으로 누를 수 있는 한계. */
  perPage: 6,
}
