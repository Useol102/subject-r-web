import { config } from '../config'

/**
 * 만족도 — `[미결정 2]`.
 * 얼굴 아이콘만으로 답할 수 있게 하고, **건너뛰기를 항상 둔다**. 강제하지 않는다.
 * 서버에 feedback 테이블이 없어 지금은 브라우저에 쌓아만 둔다.
 */
const FACES3 = [
  { score: 1, ico: '🙁', label: '별로였어요' },
  { score: 2, ico: '😐', label: '보통이에요' },
  { score: 3, ico: '😊', label: '좋았어요' },
]
const FACES5 = [
  { score: 1, ico: '😣', label: '많이 별로' },
  { score: 2, ico: '🙁', label: '별로' },
  { score: 3, ico: '😐', label: '보통' },
  { score: 4, ico: '🙂', label: '좋음' },
  { score: 5, ico: '😄', label: '아주 좋음' },
]

export function Feedback({
  onPick, onSkip,
}: { onPick: (score: number, scale: number) => void; onSkip: () => void }) {
  const scale = config.feedback === 5 ? 5 : 3
  const faces = scale === 5 ? FACES5 : FACES3

  return (
    <div className="screen">
      <div className="body body--center" style={{ gap: '1rem' }}>
        <div className="h1">잘 안내해 드렸나요?</div>
        <div className="faces">
          {faces.map((f) => (
            <button key={f.score} className="face" onClick={() => onPick(f.score, scale)}>
              <span className="face__ico">{f.ico}</span>
              <span className="face__label">{f.label}</span>
            </button>
          ))}
        </div>
        <button className="big big--ghost" onClick={onSkip} style={{ marginTop: '.6rem' }}>
          건너뛰기
        </button>
      </div>
    </div>
  )
}
