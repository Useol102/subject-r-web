import { CATEGORY_ICON } from '../components/icons'
import type { Poi } from '../types'

/**
 * 확인 화면 — `[미결정 1]`.
 * 잘못 눌렀을 때 되돌릴 기회를 주려고 목적지 이름을 크게 다시 보여준다.
 * VITE_CONFIRM_STEP=off 면 이 화면은 건너뛴다.
 */
export function Confirm({
  poi, onYes, onNo, busy,
}: { poi: Poi; onYes: () => void; onNo: () => void; busy: boolean }) {
  return (
    <div className="screen">
      <div className="body body--center" style={{ gap: '1.4rem' }}>
        <div style={{ fontSize: '4.4rem', lineHeight: 1 }}>{CATEGORY_ICON[poi.category]}</div>
        <div>
          <div className="big-name">{poi.name_ko}</div>
          <div className="h1" style={{ marginTop: '.4rem' }}>여기로 갈까요?</div>
        </div>

        {!poi.wheelchair_accessible ? (
          <div className="lead" style={{ color: 'var(--warn)', fontWeight: 700 }}>
            휠체어로는 가기 어려운 곳이에요.
          </div>
        ) : null}

        <div className="rowbtns" style={{ width: '100%', maxWidth: '38rem' }}>
          <button className="big big--ghost big--huge" onClick={onNo} disabled={busy}>
            아니요
          </button>
          <button className="big big--go big--huge" onClick={onYes} disabled={busy}>
            {busy ? '준비 중…' : '네, 갈게요'}
          </button>
        </div>
      </div>
    </div>
  )
}
