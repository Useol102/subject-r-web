import { useEffect } from 'react'

export function Canceled({ onNext }: { onNext: () => void }) {
  useEffect(() => {
    const t = window.setTimeout(onNext, 3200)
    return () => window.clearTimeout(t)
  }, [onNext])

  return (
    <div className="screen" onClick={onNext}>
      <div className="body body--center" style={{ gap: '1rem' }}>
        <div className="result-ico result-ico--stop">✕</div>
        <div className="h1">취소되었습니다</div>
        <div className="lead">필요하시면 언제든 다시 불러 주세요.</div>
      </div>
    </div>
  )
}
