import { useMemo, useState } from 'react'
import { config } from '../config'
import { CATEGORY_ICON } from '../components/icons'
import type { Poi } from '../types'

/**
 * 목적지 선택.
 * 7인치에 손가락으로 누를 수 있는 크기 한계 때문에 한 화면에 6개만 둔다.
 * 더 있으면 "다음" 으로 넘긴다 — 스크롤은 어르신이 놓치기 쉽다.
 */
export function DestinationList({
  pois, onPick, onBack,
}: { pois: Poi[]; onPick: (p: Poi) => void; onBack: () => void }) {
  const [page, setPage] = useState(0)
  const pages = Math.max(1, Math.ceil(pois.length / config.perPage))
  const shown = useMemo(
    () => pois.slice(page * config.perPage, page * config.perPage + config.perPage),
    [pois, page],
  )

  return (
    <div className="screen">
      <div className="body">
        <div className="h2">어디로 가시겠어요?</div>

        <div className="dests">
          {shown.map((p) => (
            <button key={p.id}
                    className={`dest${p.wheelchair_accessible ? '' : ' dest--blocked'}`}
                    onClick={() => onPick(p)}>
              <span className="dest__ico">{CATEGORY_ICON[p.category]}</span>
              <span className="dest__name">{p.label}</span>
              {!p.wheelchair_accessible
                ? <span className="dest__wc">휠체어는 어려워요</span> : null}
            </button>
          ))}
        </div>

        <div className="pager">
          <button className="big big--ghost" onClick={onBack}
                  style={{ fontSize: '1.15rem', minHeight: '3.2rem' }}>
            ← 처음으로
          </button>
          {pages > 1 ? (
            <>
              <div className="pager__dots">
                {Array.from({ length: pages }, (_, i) => (
                  <span key={i} className={`pager__dot${i === page ? ' pager__dot--on' : ''}`} />
                ))}
              </div>
              <button className="big big--brand"
                      style={{ fontSize: '1.15rem', minHeight: '3.2rem' }}
                      onClick={() => setPage((p) => (p + 1) % pages)}>
                다음 →
              </button>
            </>
          ) : null}
        </div>
      </div>
    </div>
  )
}
