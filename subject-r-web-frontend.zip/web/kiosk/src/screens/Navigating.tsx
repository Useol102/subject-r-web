import { useEffect, useState } from 'react'
import { config } from '../config'
import { CATEGORY_ICON } from '../components/icons'
import type { Poi, Trip } from '../types'

/**
 * 안내 중.
 *
 * `사용자-진행상황` 에 필요한 "남은 거리" API 가 아직 없다 (pose_log 미구현).
 * 그래서 숫자를 지어내지 않고 **불확정 진행 막대 + 경과 시간**만 보여준다.
 * 위치 API가 생기면 이 화면의 막대만 실제 진행률로 바꾸면 된다.
 *
 * 취소 버튼은 화면의 1/3 을 차지한다 — 급할 때 정확히 누를 수 있어야 한다.
 */
export function Navigating({
  poi, trip, onCancel, onArrived,
}: { poi: Poi; trip: Trip | null; onCancel: () => void; onArrived: () => void }) {
  const [sec, setSec] = useState(0)
  useEffect(() => {
    const t = window.setInterval(() => setSec((s) => s + 1), 1000)
    return () => window.clearInterval(t)
  }, [])

  const mm = String(Math.floor(sec / 60)).padStart(2, '0')
  const ss = String(sec % 60).padStart(2, '0')

  return (
    <div className="screen">
      <div className="body">
        <div className="nav-grid">
          <div className="nav-card">
            <div className="walker">
              <span>{CATEGORY_ICON[poi.category]}</span>
              <span className="walker__dots"><i /><i /><i /></span>
              <span>🤖</span>
            </div>
            <div className="h1">{poi.name_ko}</div>
            <div className="statusline">까지 모시고 갈게요</div>
            <div className="indet"><i /></div>
            <div className="elapsed">
              {mm}:{ss} 지남
              {trip?.planned_distance_m
                ? ` · 약 ${trip.planned_distance_m.toFixed(0)}m 거리` : ''}
            </div>
            {config.arrivalBy === 'staff' ? (
              <button className="big big--go" onClick={onArrived}
                      style={{ marginTop: '.4rem' }}>
                도착했어요
              </button>
            ) : null}
          </div>

          <button className="cancel-huge" onClick={onCancel}>
            ✕ 그만할래요
          </button>
        </div>
      </div>
    </div>
  )
}
