import { useEffect, useState } from 'react'
import type { Robot } from '../types'

/** 대기 화면 — 화면 어디를 눌러도 시작된다. 버튼을 정확히 찾지 않아도 되게. */
export function Idle({ robot, onStart }: { robot: Robot | null; onStart: () => void }) {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 20_000)
    return () => window.clearInterval(t)
  }, [])

  const hour = Number(now.toLocaleString('en-US', {
    timeZone: 'Asia/Seoul', hour: '2-digit', hour12: false,
  }))
  const greet = hour < 11 ? '안녕하세요' : hour < 17 ? '안녕하세요' : '안녕하세요'

  return (
    <div className="idle" onClick={onStart} role="button" tabIndex={0}
         onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onStart() }}>
      <div className="idle__clock">
        {now.toLocaleTimeString('ko-KR', {
          timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit', hour12: false,
        })}
      </div>

      <div>
        <div className="idle__face">🤖</div>
        <div className="idle__hi">{greet}</div>
        <div className="idle__sub">
          제가 <b>{robot?.name ?? '안내 로봇'}</b>입니다.<br />
          가고 싶은 곳까지 함께 가 드릴게요.
        </div>
        <button className="idle__tap">화면을 눌러 주세요</button>
      </div>

      <div className="idle__foot">Subject R · 베리어프리 안내 로봇</div>
    </div>
  )
}
