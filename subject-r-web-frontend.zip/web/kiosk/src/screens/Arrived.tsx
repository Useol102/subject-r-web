import { useEffect } from 'react'
import { speak } from '../lib/speech'
import { CATEGORY_ICON } from '../components/icons'
import type { Poi } from '../types'

/**
 * 도착 안내 — 화면과 음성을 **동시에**.
 * 시력이 약하면 음성으로, 청력이 약하면 글자로 전달되게.
 */
export function Arrived({
  poi, onNext, autoNextSec = 6,
}: { poi: Poi; onNext: () => void; autoNextSec?: number }) {
  useEffect(() => {
    speak(poi.voice_script ?? `${poi.name_ko}에 도착했습니다.`)
    const t = window.setTimeout(onNext, autoNextSec * 1000)
    return () => window.clearTimeout(t)
  }, [poi, onNext, autoNextSec])

  return (
    <div className="screen" onClick={onNext}>
      <div className="body body--center" style={{ gap: '1rem' }}>
        <div className="result-ico result-ico--go">✓</div>
        <div style={{ fontSize: '3.4rem' }}>{CATEGORY_ICON[poi.category]}</div>
        <div className="big-name" style={{ color: 'var(--go)' }}>{poi.name_ko}</div>
        <div className="h1">도착했습니다</div>
        <div className="lead">{poi.voice_script ?? '조심히 다녀오세요.'}</div>
      </div>
    </div>
  )
}
