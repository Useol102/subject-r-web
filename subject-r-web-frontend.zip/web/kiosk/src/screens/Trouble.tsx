import type { Poi } from '../types'

/**
 * 장애물·오류 — "잠시만요".
 *
 * `[미결정 4]` 오류 문구. "경로 계획 실패" 같은 기계 용어는 쓰지 않는다.
 * 무슨 일이 일어났는지가 아니라 **지금 어떻게 하면 되는지**만 말한다.
 */
export function Trouble({
  poi, kind, onRetry, onGiveUp,
}: {
  poi: Poi | null
  kind: 'paused' | 'failed'
  onRetry: () => void
  onGiveUp: () => void
}) {
  const failed = kind === 'failed'
  return (
    <div className="screen">
      <div className="body body--center" style={{ gap: '1.1rem' }}>
        <div className={`result-ico result-ico--${failed ? 'stop' : 'warn'}`}>
          {failed ? '🙇' : '✋'}
        </div>
        <div className="h1">
          {failed ? '지금은 모셔다 드리기 어려워요' : '잠시만 기다려 주세요'}
        </div>
        <div className="lead">
          {failed
            ? '가까이 있는 직원에게 도움을 요청해 주세요.'
            : <>앞에 무언가 있어서 잠깐 멈췄어요.<br />곧 다시 출발할게요.</>}
          {poi ? <><br /><b>{poi.name_ko}</b>(으)로 가는 중이었어요.</> : null}
        </div>

        <div className={`rowbtns${failed ? ' rowbtns--1' : ''}`}
             style={{ width: '100%', maxWidth: '38rem', marginTop: '.4rem' }}>
          {!failed ? (
            <button className="big big--ghost" onClick={onGiveUp}>그만할래요</button>
          ) : null}
          <button className={`big ${failed ? 'big--brand' : 'big--go'}`}
                  onClick={failed ? onGiveUp : onRetry}>
            {failed ? '처음으로' : '계속 갈게요'}
          </button>
        </div>
      </div>
    </div>
  )
}
