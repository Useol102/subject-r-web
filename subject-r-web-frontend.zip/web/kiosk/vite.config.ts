import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 키오스크는 5174. Jetson 의 크로미움 키오스크 모드에서 이 주소를 연다.
//
// VITE_MOCK=on 이면 백엔드 없이 도는 데모 번들(`npm run build:demo`).
const demo = process.env.VITE_MOCK === 'on'

export default defineConfig({
  plugins: [react()],
  base: './',           // Jetson 로컬 파일/임의 경로에서 열어도 깨지지 않게
  server: { port: 5174, host: true },
  preview: { port: 5174 },
  build: {
    assetsInlineLimit: demo ? 1024 * 1024 : 4096,
    cssCodeSplit: !demo,
    rollupOptions: { output: { inlineDynamicImports: demo } },
  },
})
