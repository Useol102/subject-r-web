/** app/schemas.py 와 1:1 대응.  백엔드 스키마를 고치면 여기도 같이 고친다. */

export type PoiCategory =
  | 'entrance' | 'lobby' | 'restroom' | 'elevator' | 'stairs'
  | 'therapy_room' | 'program_room' | 'office' | 'cafeteria'
  | 'charging_station' | 'waiting_area' | 'other'

export type ZoneType = 'keepout' | 'slow' | 'caution' | 'service_area'
export type RobotStatus = 'offline' | 'idle' | 'driving' | 'charging' | 'error' | 'estop'
export type UserRole = 'admin' | 'staff' | 'viewer'
export type TripMode = 'guide' | 'follow' | 'manual' | 'return_to_charge'
export type TripStatus =
  | 'requested' | 'navigating' | 'paused' | 'arrived'
  | 'completed' | 'canceled' | 'failed'
export type TripRequester = 'kiosk' | 'dashboard' | 'robot_auto'
export type TripEventType =
  | 'obstacle_detected' | 'obstacle_cleared' | 'replan'
  | 'estop_pressed' | 'estop_released' | 'manual_override'
  | 'paused' | 'resumed' | 'waypoint_reached' | 'arrived'
  | 'low_battery' | 'localization_lost' | 'error'

export interface Poi {
  id: number
  code: string
  name_ko: string
  label: string
  category: PoiCategory
  x: number
  y: number
  approach_yaw: number | null
  voice_script: string | null
  wheelchair_accessible: boolean
  display_order: number
}

export interface PoiAdmin {
  id: number
  map_id: number
  code: string
  name_ko: string
  name_short: string | null
  category: PoiCategory
  x: number
  y: number
  approach_yaw: number | null
  voice_script: string | null
  voice_file_uri: string | null
  wheelchair_accessible: boolean
  is_selectable: boolean
  is_active: boolean
  display_order: number
  created_at: string
  updated_at: string
}

export interface PoiCreate {
  map_id: number
  code: string
  name_ko: string
  name_short?: string | null
  category: PoiCategory
  x: number
  y: number
  approach_yaw?: number | null
  voice_script?: string | null
  wheelchair_accessible?: boolean
  voice_file_uri?: string | null
  is_selectable?: boolean
  display_order?: number
}

export type PoiUpdate = Partial<Omit<PoiCreate, 'map_id'>>

export interface AppUser {
  id: number
  email: string
  display_name: string
  role: UserRole
  facility_id: number | null
  is_active: boolean
  last_login_at: string | null
}

export interface TokenOut {
  access_token: string
  token_type: string
  expires_in_minutes: number
  user: AppUser
}

export interface Zone {
  id: number
  name: string
  zone_type: ZoneType
  speed_limit_mps: number | null
  priority: number
  polygon: number[][]
}

export interface RouteEdge {
  id: number
  from_poi_id: number
  to_poi_id: number
  distance_m: number
  is_bidirectional: boolean
  slope_pct: number
  has_step: boolean
  min_width_m: number | null
}

export interface FloorMapMeta {
  id: number
  facility_id: number
  floor: number
  version: number
  name: string | null
  pgm_uri: string
  yaml_uri: string
  resolution_m: number
  origin_x: number
  origin_y: number
  origin_yaw: number
  width_px: number | null
  height_px: number | null
  is_active: boolean
}

export interface MapBundle {
  map: FloorMapMeta
  pois: Poi[]
  zones: Zone[]
  edges: RouteEdge[]
  generated_at: string
  etag: string
}

export interface Robot {
  id: number
  uuid: string
  serial: string
  name: string
  model: string | null
  current_map_id: number | null
  status: RobotStatus
  battery_pct: number | null
  last_seen_at: string | null
}

export interface Trip {
  id: number
  uuid: string
  robot_id: number
  map_id: number
  mode: TripMode
  status: TripStatus
  origin_poi_id: number | null
  dest_poi_id: number | null
  requested_by: TripRequester
  is_simulated: boolean
  requested_at: string
  started_at: string | null
  ended_at: string | null
  planned_distance_m: number | null
  actual_distance_m: number | null
  abort_reason: string | null
}

export interface TripEvent {
  id: number
  ts: string
  event_type: TripEventType
  severity: number
  x: number | null
  y: number | null
  payload: Record<string, unknown>
}

/** 아직 서버에 API가 없어 화면만 있는 기능을 표시할 때 쓴다. */
export const ROBOT_POSE_API_READY = false
