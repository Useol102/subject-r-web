/**
 * 데모용 가짜 API.
 *
 * `VITE_MOCK=on` 으로 빌드하면 window.fetch 를 가로채서
 * 백엔드 없이 화면을 그대로 굴린다. **개발/시연 전용이다.**
 * 실제 빌드(`npm run build`)에는 이 코드가 들어가지 않는다.
 *
 * 데이터 모양은 schema/002_seed_dev.sql 을 따랐다.
 */
import type {
  AppUser, FloorMapMeta, PoiAdmin, Robot, Trip, TripEvent, TripStatus,
} from '../types'

const nowIso = () => new Date().toISOString()
const ago = (sec: number) => new Date(Date.now() - sec * 1000).toISOString()

const MAPS: FloorMapMeta[] = [{
  id: 1, facility_id: 1, floor: 1, version: 2, name: '1층 데모 지도',
  pgm_uri: 's3://maps/demo/1f_v2.pgm', yaml_uri: 's3://maps/demo/1f_v2.yaml',
  resolution_m: 0.05, origin_x: -10, origin_y: -10, origin_yaw: 0,
  width_px: 800, height_px: 600, is_active: true,
}, {
  id: 2, facility_id: 1, floor: 1, version: 1, name: '1층 초기 지도',
  pgm_uri: 's3://maps/demo/1f_v1.pgm', yaml_uri: 's3://maps/demo/1f_v1.yaml',
  resolution_m: 0.05, origin_x: -10, origin_y: -10, origin_yaw: 0,
  width_px: 800, height_px: 600, is_active: false,
}]

type Seed = [string, string, string | null, PoiAdmin['category'], number, number,
             number | null, string | null, boolean, boolean, number]
const SEED: Seed[] = [
  ['ENTRANCE_1F', '정문 출입구', '출입구', 'entrance', 2.0, 0.5, 1.57, '정문에 도착했습니다.', true, true, 1],
  ['LOBBY_1F', '1층 로비', '로비', 'lobby', 5.0, 3.0, 0, '로비에 도착했습니다.', true, true, 2],
  ['RESTROOM_1F', '1층 화장실', '화장실', 'restroom', 12.0, 4.0, 3.14, '화장실 앞에 도착했습니다.', true, true, 3],
  ['THERAPY_1F', '물리치료실', '물리치료', 'therapy_room', 18.0, 7.5, 0, '물리치료실에 도착했습니다.', true, true, 4],
  ['PROGRAM_1F', '프로그램실', '프로그램', 'program_room', 22.0, 2.0, 1.57, '프로그램실에 도착했습니다.', true, true, 5],
  ['ELEV_1F', '1층 엘리베이터', '엘리베이터', 'elevator', 15.0, -2.0, 3.14, '엘리베이터 앞에 도착했습니다.', true, true, 6],
  ['CAFE_1F', '1층 식당', '식당', 'cafeteria', 8.0, 8.5, 0, '식당에 도착했습니다.', true, true, 7],
  ['WAIT_1F', '대기 의자', '대기실', 'waiting_area', 6.5, -3.5, 0, '대기 공간입니다. 편히 앉아 계세요.', true, true, 8],
  ['STAIRS_1F', '1층 계단', '계단', 'stairs', 16.5, -4.0, 3.14, null, false, true, 9],
  ['CHARGE_1F', '충전 스테이션', null, 'charging_station', 0.5, -1.0, 0, null, true, false, 99],
]

let poiSeq = 0
const POIS: PoiAdmin[] = SEED.map(([code, ko, short, cat, x, y, yaw, voice, wc, sel, ord]) => ({
  id: ++poiSeq, map_id: 1, code, name_ko: ko, name_short: short, category: cat,
  x, y, approach_yaw: yaw, voice_script: voice, voice_file_uri: null,
  wheelchair_accessible: wc, is_selectable: sel, is_active: code !== 'STAIRS_1F',
  display_order: ord, created_at: ago(86400 * 12), updated_at: ago(86400),
}))

const ZONES = [
  { id: 1, name: '계단 진입금지', zone_type: 'keepout' as const, speed_limit_mps: null,
    priority: 10, polygon: [[15, -5], [18, -5], [18, -3], [15, -3], [15, -5]] },
  { id: 2, name: '로비 혼잡구역 서행', zone_type: 'slow' as const, speed_limit_mps: 0.3,
    priority: 5, polygon: [[3, 1], [8, 1], [8, 5], [3, 5], [3, 1]] },
  { id: 3, name: '안내 서비스 범위', zone_type: 'service_area' as const, speed_limit_mps: null,
    priority: 1, polygon: [[-1, -6], [24, -6], [24, 10], [-1, 10], [-1, -6]] },
]

const ROBOTS: Robot[] = [
  { id: 1, uuid: 'a1b2c3d4-0000-4000-8000-000000000001', serial: 'SBR-0001', name: '토리',
    model: 'jetson-orin-nano-4wd', current_map_id: 1, status: 'driving',
    battery_pct: 74, last_seen_at: nowIso() },
  { id: 2, uuid: 'a1b2c3d4-0000-4000-8000-000000000002', serial: 'SBR-0002', name: '도리',
    model: 'jetson-orin-nano-4wd', current_map_id: 1, status: 'charging',
    battery_pct: 38, last_seen_at: ago(9) },
]

const USERS: AppUser[] = [
  { id: 1, email: 'admin@demo.org', display_name: '김관리', role: 'admin',
    facility_id: 1, is_active: true, last_login_at: nowIso() },
  { id: 2, email: 'staff@demo.org', display_name: '이복지', role: 'staff',
    facility_id: 1, is_active: true, last_login_at: ago(3600 * 20) },
  { id: 3, email: 'view@demo.org', display_name: '박조회', role: 'viewer',
    facility_id: 1, is_active: true, last_login_at: ago(86400 * 4) },
]

// ------------------------------------------------------------------ 안내 이력
let rnd = 20260822
const rand = () => { rnd = (rnd * 1103515245 + 12345) % 2147483648; return rnd / 2147483648 }
const pick = <T,>(xs: T[]) => xs[Math.floor(rand() * xs.length)]

const TRIPS: Trip[] = []
const EVENTS = new Map<number, TripEvent[]>()
let tripSeq = 0
let evSeq = 0

const HOTSPOTS = [[8.6, 3.4], [8.4, 3.7], [12.3, 4.2], [12.6, 3.9], [12.4, 4.4],
                  [5.6, 2.9], [15.7, -1.6], [8.8, 3.2]]

function makeTrip(minutesAgo: number, status: TripStatus): Trip {
  const id = ++tripSeq
  const dest = pick(POIS.filter((p) => p.is_selectable && p.is_active))
  const req = new Date(Date.now() - minutesAgo * 60_000)
  const started = new Date(req.getTime() + 8000 + rand() * 14000)
  const done = status === 'completed' || status === 'failed' || status === 'canceled'
  const ended = done ? new Date(started.getTime() + 40_000 + rand() * 190_000) : null
  const t: Trip = {
    id, uuid: `${String(id).padStart(8, '0')}-0000-4000-8000-000000000000`,
    robot_id: rand() < 0.75 ? 1 : 2, map_id: 1, mode: 'guide', status,
    origin_poi_id: 2, dest_poi_id: dest.id,
    requested_by: rand() < 0.78 ? 'kiosk' : 'dashboard', is_simulated: false,
    requested_at: req.toISOString(), started_at: started.toISOString(),
    ended_at: ended ? ended.toISOString() : null,
    planned_distance_m: Math.round((6 + rand() * 22) * 10) / 10,
    actual_distance_m: ended ? Math.round((6 + rand() * 25) * 10) / 10 : null,
    abort_reason: status === 'failed' ? '사람이 길을 막아 통과하지 못함'
      : status === 'canceled' ? '사용자가 화면에서 취소' : null,
  }
  const evs: TripEvent[] = []
  const n = Math.floor(rand() * 4)
  for (let k = 0; k < n; k++) {
    const [hx, hy] = pick(HOTSPOTS)
    evs.push({
      id: ++evSeq, ts: new Date(started.getTime() + 15_000 * (k + 1)).toISOString(),
      event_type: pick(['obstacle_detected', 'replan', 'obstacle_cleared',
        'waypoint_reached', 'low_battery'] as TripEvent['event_type'][]),
      severity: pick([0, 1, 1, 2]),
      x: Math.round((hx + (rand() - 0.5) * 0.8) * 100) / 100,
      y: Math.round((hy + (rand() - 0.5) * 0.8) * 100) / 100,
      payload: { class: pick(['person', 'wheelchair', 'unknown']), distance_m: Math.round(rand() * 24) / 10 },
    })
  }
  if (ended) {
    evs.push({
      id: ++evSeq, ts: ended.toISOString(),
      event_type: status === 'completed' ? 'arrived' : 'error',
      severity: status === 'completed' ? 0 : 2, x: dest.x, y: dest.y, payload: {},
    })
  }
  EVENTS.set(id, evs)
  return t
}

// 오래된 것부터 만들어서 최신순으로 뒤집는다.
const HISTORY: TripStatus[] = ['completed', 'completed', 'completed', 'completed',
  'completed', 'canceled', 'completed', 'completed', 'failed', 'completed']
for (let i = 46; i >= 1; i--) {
  TRIPS.unshift(makeTrip(i * 19 + Math.floor(rand() * 12), HISTORY[i % HISTORY.length]))
}
// 지금 진행 중인 것 두 건
TRIPS.unshift(makeTrip(3, 'navigating'))
TRIPS.unshift(makeTrip(1, 'paused'))
TRIPS.sort((a, b) => b.requested_at.localeCompare(a.requested_at))

// ------------------------------------------------------------------ 시간 흐름
// 폴링이 진짜로 동작하는 걸 보여주려고, 읽을 때마다 조금씩 상태를 움직인다.
let lastTick = Date.now()
function tick() {
  const dt = (Date.now() - lastTick) / 1000
  if (dt < 1) return
  lastTick = Date.now()

  for (const r of ROBOTS) {
    r.last_seen_at = nowIso()
    if (r.status === 'charging') r.battery_pct = Math.min(100, (r.battery_pct ?? 0) + dt * 0.12)
    else r.battery_pct = Math.max(8, (r.battery_pct ?? 100) - dt * 0.05)
    r.battery_pct = Math.round(r.battery_pct)
  }

  const live = TRIPS.filter((t) => ['requested', 'navigating', 'paused'].includes(t.status))
  for (const t of live) {
    const age = (Date.now() - new Date(t.requested_at).getTime()) / 1000
    if (t.status === 'requested' && age > 6) t.status = 'navigating'
    else if (t.status === 'paused' && age > 150) t.status = 'navigating'
    else if (t.status === 'navigating' && age > 240) {
      t.status = 'completed'
      t.ended_at = nowIso()
      t.actual_distance_m = Math.round(((t.planned_distance_m ?? 10) + rand() * 3) * 10) / 10
      const evs = EVENTS.get(t.id) ?? []
      const dest = POIS.find((p) => p.id === t.dest_poi_id)
      evs.push({ id: ++evSeq, ts: nowIso(), event_type: 'arrived', severity: 0,
        x: dest?.x ?? 0, y: dest?.y ?? 0, payload: {} })
      EVENTS.set(t.id, evs)
    }
  }
  // 진행 중인 안내가 없으면 새로 하나 들어온 것처럼 만든다.
  if (!TRIPS.some((t) => ['requested', 'navigating', 'paused'].includes(t.status))) {
    TRIPS.unshift(makeTrip(0, 'requested'))
  }
}

// ------------------------------------------------------------------ 라우팅
const poiOut = (p: PoiAdmin) => ({
  id: p.id, code: p.code, name_ko: p.name_ko, label: p.name_short ?? p.name_ko,
  category: p.category, x: p.x, y: p.y, approach_yaw: p.approach_yaw,
  voice_script: p.voice_script, wheelchair_accessible: p.wheelchair_accessible,
  display_order: p.display_order,
})

const ok = (body: unknown, status = 200) =>
  new Response(status === 204 ? null : JSON.stringify(body), {
    status, headers: { 'Content-Type': 'application/json' },
  })
const err = (status: number, detail: string) =>
  new Response(JSON.stringify({ detail }), {
    status, headers: { 'Content-Type': 'application/json' },
  })

let userSeq = 100

function handle(method: string, path: string, q: URLSearchParams, body: any): Response {
  tick()
  const m = (re: RegExp) => re.exec(path)

  if (path === '/health') return ok({ status: 'ok', postgis: '3.4 (mock)' })

  if (method === 'POST' && path === '/auth/login') {
    const u = USERS.find((x) => x.email === String(body?.email ?? '').toLowerCase()) ?? USERS[0]
    if (!u.is_active) return err(403, '비활성화된 계정이다')
    u.last_login_at = nowIso()
    return ok({ access_token: `demo.${u.id}`, token_type: 'bearer',
      expires_in_minutes: 480, user: u })
  }
  if (path === '/auth/me') return ok(USERS[0])
  if (method === 'POST' && path === '/auth/change-password') {
    if (String(body?.current_password ?? '').length < 4) return err(400, '현재 비밀번호가 맞지 않다')
    return ok(null, 204)
  }

  if (path === '/users') {
    if (method === 'GET') return ok(USERS)
    if (method === 'POST') {
      if (USERS.some((u) => u.email === body.email)) return err(409, `이미 있는 이메일이다: ${body.email}`)
      const u: AppUser = { id: ++userSeq, email: body.email, display_name: body.display_name,
        role: body.role, facility_id: 1, is_active: true, last_login_at: null }
      USERS.push(u)
      return ok(u, 201)
    }
  }
  let r = m(/^\/users\/(\d+)$/)
  if (r && method === 'DELETE') {
    const u = USERS.find((x) => x.id === Number(r![1]))
    if (!u) return err(404, '없는 계정이다')
    if (u.id === USERS[0].id) return err(400, '자기 계정은 비활성화할 수 없다')
    if (u.role === 'admin' && USERS.filter((x) => x.role === 'admin' && x.is_active).length <= 1)
      return err(409, '마지막 admin 계정은 비활성화할 수 없다')
    u.is_active = false
    return ok(u)
  }

  if (path === '/maps') return ok(q.get('active_only') === 'true' ? MAPS.filter((x) => x.is_active) : MAPS)
  r = m(/^\/maps\/(\d+)$/)
  if (r) {
    const mp = MAPS.find((x) => x.id === Number(r![1]))
    return mp ? ok(mp) : err(404, `map ${r[1]} 없음`)
  }
  r = m(/^\/maps\/(\d+)\/bundle$/)
  if (r) return ok({
    map: MAPS.find((x) => x.id === Number(r![1])) ?? MAPS[0],
    pois: POIS.filter((p) => p.is_active).map(poiOut),
    zones: ZONES, edges: [], generated_at: nowIso(),
    etag: 'demo0f1e2d3c4b5a6978',
  })
  r = m(/^\/maps\/(\d+)\/pois\/admin$/)
  if (r) return ok([...POIS].sort((a, b) => a.display_order - b.display_order))
  r = m(/^\/maps\/(\d+)\/pois$/)
  if (r) {
    const all = q.get('all_pois') === 'true'
    return ok(POIS.filter((p) => p.is_active && (all || p.is_selectable))
      .sort((a, b) => a.display_order - b.display_order).map(poiOut))
  }
  r = m(/^\/maps\/(\d+)\/pois\/order$/)
  if (r && method === 'PATCH') {
    for (const it of body.items ?? []) {
      const p = POIS.find((x) => x.id === it.poi_id)
      if (p) p.display_order = it.display_order
    }
    return ok(POIS.filter((p) => p.is_active).map(poiOut))
  }

  if (path === '/pois' && method === 'POST') {
    if (POIS.some((p) => p.code === body.code)) return err(409, `이미 있는 코드다: ${body.code}`)
    const mp = MAPS[0]
    const w = (mp.width_px ?? 800) * mp.resolution_m
    const h = (mp.height_px ?? 600) * mp.resolution_m
    if (body.x < mp.origin_x || body.x > mp.origin_x + w
      || body.y < mp.origin_y || body.y > mp.origin_y + h)
      return err(400, '좌표가 지도 범위를 벗어난다')
    const p: PoiAdmin = {
      id: ++poiSeq, map_id: 1, code: body.code, name_ko: body.name_ko,
      name_short: body.name_short ?? null, category: body.category,
      x: body.x, y: body.y, approach_yaw: body.approach_yaw ?? null,
      voice_script: body.voice_script ?? null, voice_file_uri: null,
      wheelchair_accessible: body.wheelchair_accessible ?? true,
      is_selectable: body.is_selectable ?? true, is_active: true,
      display_order: body.display_order ?? POIS.length + 1,
      created_at: nowIso(), updated_at: nowIso(),
    }
    POIS.push(p)
    return ok(p, 201)
  }
  r = m(/^\/pois\/(\d+)$/)
  if (r) {
    const p = POIS.find((x) => x.id === Number(r![1]))
    if (!p) return err(404, `poi ${r[1]} 없음`)
    if (method === 'GET') return ok(p)
    if (method === 'PATCH') {
      Object.assign(p, body)
      p.updated_at = nowIso()
      return ok(p)
    }
    if (method === 'DELETE') { p.is_active = false; p.updated_at = nowIso(); return ok(p) }
  }
  r = m(/^\/pois\/(\d+)\/restore$/)
  if (r && method === 'POST') {
    const p = POIS.find((x) => x.id === Number(r![1]))
    if (!p) return err(404, `poi ${r[1]} 없음`)
    p.is_active = true; p.updated_at = nowIso()
    return ok(p)
  }

  if (path === '/robots') return ok(ROBOTS)
  r = m(/^\/robots\/(\d+)$/)
  if (r) {
    const rb = ROBOTS.find((x) => x.id === Number(r![1]))
    return rb ? ok(rb) : err(404, '로봇 없음')
  }

  if (path === '/trips') {
    if (method === 'GET') {
      let xs = [...TRIPS]
      const rid = q.get('robot_id')
      if (rid) xs = xs.filter((t) => t.robot_id === Number(rid))
      if (q.get('include_simulated') === 'false') xs = xs.filter((t) => !t.is_simulated)
      return ok(xs.slice(0, Number(q.get('limit') ?? 50)))
    }
    if (method === 'POST') {
      const rb = ROBOTS.find((x) => x.id === body.robot_id)
      if (!rb) return err(404, `robot ${body.robot_id} 없음`)
      if (body.mode === 'guide' && !body.dest_poi_id)
        return err(400, 'guide 모드에는 dest_poi_id 가 필요하다')
      const dest = POIS.find((p) => p.id === body.dest_poi_id)
      const t: Trip = {
        id: ++tripSeq, uuid: `${String(tripSeq).padStart(8, '0')}-0000-4000-8000-000000000000`,
        robot_id: rb.id, map_id: 1, mode: body.mode, status: 'requested',
        origin_poi_id: body.origin_poi_id ?? null, dest_poi_id: body.dest_poi_id ?? null,
        requested_by: body.requested_by ?? 'kiosk', is_simulated: !!body.is_simulated,
        requested_at: nowIso(), started_at: null, ended_at: null,
        planned_distance_m: dest ? Math.round(Math.hypot(dest.x - 5, dest.y - 3) * 10) / 10 : null,
        actual_distance_m: null, abort_reason: null,
      }
      TRIPS.unshift(t)
      EVENTS.set(t.id, [])
      return ok(t, 201)
    }
  }
  r = m(/^\/trips\/(\d+)$/)
  if (r && method === 'PATCH') {
    const t = TRIPS.find((x) => x.id === Number(r![1]))
    if (!t) return err(404, `trip ${r[1]} 없음`)
    if (body.status) {
      t.status = body.status
      if (body.status === 'navigating' && !t.started_at) t.started_at = nowIso()
      if (['completed', 'canceled', 'failed', 'arrived'].includes(body.status) && !t.ended_at)
        t.ended_at = nowIso()
    }
    if (body.abort_reason !== undefined) t.abort_reason = body.abort_reason
    if (body.actual_distance_m !== undefined) t.actual_distance_m = body.actual_distance_m
    return ok(t)
  }
  r = m(/^\/trips\/(\d+)\/events$/)
  if (r) {
    const id = Number(r[1])
    if (method === 'GET') return ok(EVENTS.get(id) ?? [])
    if (method === 'POST') {
      const e: TripEvent = { id: ++evSeq, ts: body.ts ?? nowIso(), event_type: body.event_type,
        severity: body.severity ?? 0, x: body.x ?? null, y: body.y ?? null,
        payload: body.payload ?? {} }
      EVENTS.set(id, [...(EVENTS.get(id) ?? []), e])
      return ok(e, 201)
    }
  }

  return err(404, `데모 서버에 없는 경로다: ${method} ${path}`)
}

export function installMock(): void {
  const real = window.fetch.bind(window)
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input
      : input instanceof URL ? input.href : input.url
    // about:srcdoc 처럼 기준 주소가 없는 곳에서도 파싱되도록 가짜 base 를 준다.
    let u: URL
    try { u = new URL(url, 'http://demo.local') } catch { return real(input as RequestInfo, init) }

    const method = (init?.method ?? 'GET').toUpperCase()
    let body: any = undefined
    if (init?.body && typeof init.body === 'string') {
      try { body = JSON.parse(init.body) } catch { body = undefined }
    }
    // 실제 서버처럼 약간의 지연을 준다 (로딩 표시가 보이게)
    await new Promise((res) => setTimeout(res, 90 + Math.random() * 120))
    return handle(method, u.pathname, u.searchParams, body)
  }
}
