import { useEffect, type ReactNode } from 'react'

export function Modal({
  title, onClose, footer, wide, children,
}: {
  title: string
  onClose: () => void
  footer?: ReactNode
  wide?: boolean
  children: ReactNode
}) {
  // ESC로 닫힌다. 직원이 마우스를 안 잡고도 빠져나올 수 있어야 한다.
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])

  return (
    <div className="modal-back" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className={`modal${wide ? ' modal--wide' : ''}`} role="dialog" aria-modal="true">
        <div className="modal__head">
          <h3>{title}</h3>
          <button className="btn btn--ghost btn--sm" style={{ marginLeft: 'auto' }}
                  onClick={onClose} aria-label="닫기">✕</button>
        </div>
        <div className="modal__body">{children}</div>
        {footer ? <div className="modal__foot">{footer}</div> : null}
      </div>
    </div>
  )
}
