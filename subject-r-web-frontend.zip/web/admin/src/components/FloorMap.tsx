/**
 * 실내 지도.  CLAUDE.md 규칙대로 Leaflet `CRS.Simple` 을 쓴다 (위경도 아님).
 *
 * 좌표계: SLAM 지도 원점 기준 **미터**.  Leaflet 의 LatLng 에는 [y, x] 순서로 넣는다.
 * 배경 이미지는 map.pgm_uri 가 s3:// 라 브라우저가 못 읽는다.
 * VITE_MAP_IMAGE_BASE 를 설정하면 `{base}/{map_id}.png` 를 깔고, 없으면 격자만 그린다.
 */
import { useMemo } from 'react'
import {
  CircleMarker, ImageOverlay, MapContainer, Marker, Polygon, Polyline, Tooltip,
  useMapEvents,
} from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import type { FloorMapMeta, Poi, PoiAdmin, PoiCategory, Zone } from '../types'
import { CATEGORY_KO } from '../lib/format'

const IMAGE_BASE = (import.meta.env.VITE_MAP_IMAGE_BASE as string | undefined)
  ?.replace(/\/$/, '')

export const CATEGORY_ICON: Record<PoiCategory, string> = {
  entrance: '🚪', lobby: '🛋️', restroom: '🚻', elevator: '🛗', stairs: '🪜',
  therapy_room: '💊', program_room: '📚', office: '🗄️', cafeteria: '🍚',
  charging_station: '🔌', waiting_area: '🪑', other: '📍',
}

const ZONE_STYLE: Record<Zone['zone_type'], { color: string; fill: string; label: string }> = {
  keepout:      { color: '#dc2626', fill: '#dc2626', label: '진입금지' },
  slow:         { color: '#d97706', fill: '#f59e0b', label: '서행' },
  caution:      { color: '#7c3aed', fill: '#8b5cf6', label: '주의' },
  service_area: { color: '#0d9488', fill: '#14b8a6', label: '서비스 구역' },
}

const TONE_HEX: Record<string, string> = {
  bad: '#dc2626', warn: '#d97706', info: '#2563eb', ok: '#15803d',
}

export interface MapPoint {
  x: number
  y: number
  label?: string
  tone?: 'bad' | 'warn' | 'info' | 'ok'
  weight?: number
}

type AnyPoi = (Poi | PoiAdmin) & { is_active?: boolean }

/** 지도 한 장이 덮는 실제 범위(미터).  width_px 가 없으면 넉넉한 기본값. */
export function mapBoundsOf(m: FloorMapMeta): L.LatLngBoundsExpression {
  const w = (m.width_px ?? 800) * m.resolution_m
  const h = (m.height_px ?? 600) * m.resolution_m
  return [
    [m.origin_y, m.origin_x],
    [m.origin_y + h, m.origin_x + w],
  ]
}

function ClickCatcher({ onPick }: { onPick: (x: number, y: number) => void }) {
  useMapEvents({
    click(e) { onPick(Number(e.latlng.lng.toFixed(2)), Number(e.latlng.lat.toFixed(2))) },
  })
  return null
}

function poiIcon(p: AnyPoi, highlight: boolean) {
  const off = p.is_active === false
  const cls = `poimark${off ? ' poimark--off' : ''}${highlight ? ' poimark--dest' : ''}`
  return L.divIcon({
    className: '',
    html: `<div class="${cls}">${CATEGORY_ICON[p.category] ?? '📍'}</div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  })
}

export function FloorMap({
  map, pois = [], zones = [], points = [], path, highlightPoiId,
  onPick, tall, showLegend = true,
}: {
  map: FloorMapMeta
  pois?: AnyPoi[]
  zones?: Zone[]
  /** 이벤트 좌표 등 임의의 점.  히트맵·사건 표시에 쓴다. */
  points?: MapPoint[]
  /** 경로선 [[x,y], ...] */
  path?: number[][]
  highlightPoiId?: number | null
  onPick?: (x: number, y: number) => void
  tall?: boolean
  showLegend?: boolean
}) {
  const bounds = useMemo(() => mapBoundsOf(map), [map])
  const imageUrl = IMAGE_BASE ? `${IMAGE_BASE}/${map.id}.png` : null

  return (
    <div>
      <div className={`mapbox${tall ? ' mapbox--tall' : ''}`}>
        <MapContainer
          crs={L.CRS.Simple}
          bounds={bounds}
          maxBounds={bounds}
          maxBoundsViscosity={0.6}
          style={{ height: '100%', width: '100%' }}
          zoomSnap={0.25}
          attributionControl={false}
        >
          {imageUrl ? <ImageOverlay url={imageUrl} bounds={bounds} opacity={0.85} /> : null}

          {zones.map((z) => {
            const s = ZONE_STYLE[z.zone_type]
            return (
              <Polygon
                key={z.id}
                positions={z.polygon.map(([x, y]) => [y, x] as [number, number])}
                pathOptions={{
                  color: s.color, fillColor: s.fill,
                  // 서비스 구역은 지도 전체를 덮을 만큼 넓다. 거의 투명하게 둔다.
                  fillOpacity: z.zone_type === 'service_area' ? 0.04 : 0.16,
                  weight: 2, dashArray: z.zone_type === 'keepout' ? undefined : '5 4',
                }}
              >
                <Tooltip sticky>
                  <b>{z.name}</b><br />
                  {s.label}
                  {z.speed_limit_mps ? ` · 제한 ${z.speed_limit_mps} m/s` : ''}
                </Tooltip>
              </Polygon>
            )
          })}

          {path && path.length > 1 ? (
            <Polyline
              positions={path.map(([x, y]) => [y, x] as [number, number])}
              pathOptions={{ color: '#2563eb', weight: 3, opacity: 0.75, dashArray: '6 5' }}
            />
          ) : null}

          {pois.map((p) => (
            <Marker
              key={p.id}
              position={[p.y, p.x]}
              icon={poiIcon(p, highlightPoiId === p.id)}
            >
              <Tooltip direction="top" offset={[0, -12]}>
                <b>{p.name_ko}</b><br />
                {CATEGORY_KO[p.category]} · {p.x.toFixed(1)}, {p.y.toFixed(1)}
                {p.is_active === false ? <><br /><i>숨김</i></> : null}
              </Tooltip>
            </Marker>
          ))}

          {points.map((pt, i) => (
            <CircleMarker
              key={i}
              center={[pt.y, pt.x]}
              radius={4 + Math.min(10, (pt.weight ?? 1) * 2.2)}
              pathOptions={{
                color: TONE_HEX[pt.tone ?? 'bad'],
                fillColor: TONE_HEX[pt.tone ?? 'bad'],
                fillOpacity: 0.35, weight: 1.5,
              }}
            >
              {pt.label ? <Tooltip direction="top">{pt.label}</Tooltip> : null}
            </CircleMarker>
          ))}

          {onPick ? <ClickCatcher onPick={onPick} /> : null}
        </MapContainer>
      </div>

      {showLegend ? (
        <div className="maplegend">
          <span><i style={{ background: '#dc2626' }} />진입금지</span>
          <span><i style={{ background: '#f59e0b' }} />서행</span>
          <span><i style={{ background: '#14b8a6' }} />서비스 구역</span>
          <span className="muted">
            좌표계: 지도 원점 기준 미터 · 해상도 {map.resolution_m} m/px
          </span>
          {onPick ? <span className="muted">지도를 클릭하면 좌표가 입력된다</span> : null}
        </div>
      ) : null}
    </div>
  )
}
