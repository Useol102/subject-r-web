import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'

interface Item { id: number; text: string; bad?: boolean }
type Push = (text: string, bad?: boolean) => void

const Ctx = createContext<Push>(() => {})
export const useToast = () => useContext(Ctx)

let seq = 0

export function ToastHost({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Item[]>([])

  const push = useCallback<Push>((text, bad) => {
    const id = ++seq
    setItems((s) => [...s, { id, text, bad }])
    window.setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), 3800)
  }, [])

  const value = useMemo(() => push, [push])

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="toasts">
        {items.map((i) => (
          <div key={i.id} className={`toast${i.bad ? ' toast--bad' : ''}`}>{i.text}</div>
        ))}
      </div>
    </Ctx.Provider>
  )
}
