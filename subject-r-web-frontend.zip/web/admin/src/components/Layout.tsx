import type { ReactNode } from 'react'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { ROLE_KO } from '../lib/format'
import type { UserRole } from '../types'

interface Item {
  to: string
  label: string
  icon: string
  need?: UserRole
  /** 서버 API가 아직 없어 화면만 있는 것 */
  soon?: boolean
}

const NAV: { group: string; items: Item[] }[] = [
  {
    group: '운영',
    items: [
      { to: '/', label: '대시보드', icon: '◉' },
      { to: '/trips', label: '안내 이력', icon: '≡' },
      { to: '/stats', label: '안내 통계', icon: '▤' },
      { to: '/heatmap', label: '장애물 다발 지점', icon: '⌖' },
    ],
  },
  {
    group: '설정',
    items: [
      { to: '/pois', label: '목적지 관리', icon: '📍', need: 'staff' },
      { to: '/zones', label: '구역 관리', icon: '⬡', need: 'staff', soon: true },
      { to: '/maps', label: '지도 관리', icon: '🗺', need: 'staff', soon: true },
      { to: '/users', label: '계정 관리', icon: '👤', need: 'admin' },
    ],
  },
]

export function Layout() {
  const { user, logout, can } = useAuth()
  const loc = useLocation()

  return (
    <div className="shell">
      <aside className="side">
        <div className="side__brand">
          <div className="side__mark">SbR</div>
          <div>
            <div className="side__title">Subject R</div>
            <div className="side__sub">안내 로봇 관리</div>
          </div>
        </div>

        <nav className="side__nav">
          {NAV.map((g) => {
            const items = g.items.filter((i) => !i.need || can(i.need))
            if (!items.length) return null
            return (
              <div key={g.group}>
                <div className="side__group">{g.group}</div>
                {items.map((i) => (
                  <NavLink
                    key={i.to}
                    to={i.to}
                    end={i.to === '/'}
                    className={({ isActive }) =>
                      `navlink${isActive || (i.to !== '/' && loc.pathname.startsWith(i.to))
                        ? ' navlink--on' : ''}`}
                  >
                    <span className="navlink__ico">{i.icon}</span>
                    {i.label}
                    {i.soon ? <span className="navlink__tag">준비</span> : null}
                  </NavLink>
                ))}
              </div>
            )
          })}
        </nav>

        <div className="side__foot">
          <div className="who">
            <div className="who__av">{user?.display_name?.slice(0, 1) ?? '?'}</div>
            <div style={{ minWidth: 0 }}>
              <div className="who__name">{user?.display_name}</div>
              <div className="who__role">{user ? ROLE_KO[user.role] : ''}</div>
            </div>
            <button className="btn btn--ghost btn--sm" style={{ marginLeft: 'auto' }}
                    onClick={logout} title="로그아웃">⏻</button>
          </div>
        </div>
      </aside>

      <div className="main">
        <Outlet />
      </div>
    </div>
  )
}

export function PageHead({
  title, sub, right,
}: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <header className="topbar">
      <div>
        <h1>{title}</h1>
        {sub ? <div className="topbar__sub">{sub}</div> : null}
      </div>
      {right ? <div className="topbar__right">{right}</div> : null}
    </header>
  )
}

/** 폴링 화면 우상단에 붙이는 "N초 전 갱신". */
export function LiveTag({ updatedAt, error }: { updatedAt: number | null; error?: string | null }) {
  if (error) return <span className="pill pill--bad"><i className="pill__dot" />연결 끊김</span>
  const sec = updatedAt ? Math.max(0, Math.round((Date.now() - updatedAt) / 1000)) : null
  return (
    <span className="pill pill--active">
      <i className="pill__dot" />
      실시간 {sec !== null ? `· ${sec}초 전` : ''}
    </span>
  )
}
