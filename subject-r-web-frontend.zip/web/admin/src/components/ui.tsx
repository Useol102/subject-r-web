/** 작은 표시 요소 모음.  화면마다 반복되는 것만 여기 둔다. */
import type { ReactNode } from 'react'

export function Pill({ tone, children }: { tone: string; children: ReactNode }) {
  return (
    <span className={`pill pill--${tone}`}>
      <i className="pill__dot" />
      {children}
    </span>
  )
}

export function Battery({ pct }: { pct: number | null }) {
  if (pct === null || pct === undefined) return <span className="muted">—</span>
  const tone = pct <= 15 ? 'bad' : pct <= 35 ? 'warn' : ''
  return (
    <span className="batt" title={`배터리 ${pct}%`}>
      <span className="batt__shell">
        <span
          className={`batt__fill${tone ? ` batt__fill--${tone}` : ''}`}
          style={{ width: `${Math.max(2, Math.min(100, pct))}%` }}
        />
      </span>
      <span className="batt__num">{pct}%</span>
    </span>
  )
}

export function Empty({ icon = '∅', children }: { icon?: string; children: ReactNode }) {
  return (
    <div className="empty">
      <span className="empty__ico">{icon}</span>
      {children}
    </div>
  )
}

export function Banner({ tone = 'info', children }: { tone?: string; children: ReactNode }) {
  return <div className={`banner banner--${tone}`}>{children}</div>
}

export function Loading({ label = '불러오는 중' }: { label?: string }) {
  return (
    <div className="empty">
      <span className="spin" style={{ marginRight: 8, verticalAlign: 'middle' }} />
      {label}
    </div>
  )
}

/**
 * 서버 API가 아직 없는 화면에 붙인다.
 * FEATURES.md 의 이름표를 그대로 적어서, 나중에 뭘 만들면 되는지 화면에서 바로 보이게 한다.
 */
export function NotReady({
  label, waiting, children,
}: { label: string; waiting: string; children?: ReactNode }) {
  return (
    <div className="notready">
      <h4>준비 중 — <code>{label}</code></h4>
      <p>{waiting}</p>
      {children}
    </div>
  )
}

export function Stat({
  label, value, unit, foot, tone,
}: {
  label: string; value: ReactNode; unit?: string; foot?: ReactNode; tone?: string
}) {
  return (
    <div className="card stat">
      <div className="stat__label">{label}</div>
      <div className="stat__value" style={tone ? { color: `var(--${tone})` } : undefined}>
        {value}
        {unit ? <span className="stat__unit">{unit}</span> : null}
      </div>
      {foot ? <div className="stat__foot">{foot}</div> : null}
    </div>
  )
}

export function Bar({
  name, value, max, text, bad,
}: { name: string; value: number; max: number; text?: string; bad?: boolean }) {
  const pct = max > 0 ? (value / max) * 100 : 0
  return (
    <div className="bar">
      <div className="bar__name" title={name}>{name}</div>
      <div className="bar__track">
        <div
          className={`bar__fill${bad ? ' bar__fill--bad' : ''}`}
          style={{ width: `${Math.max(pct > 0 ? 2 : 0, pct)}%` }}
        />
      </div>
      <div className="bar__val">{text ?? value}</div>
    </div>
  )
}
