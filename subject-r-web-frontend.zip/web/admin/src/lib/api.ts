/**
 * FastAPI 클라이언트.
 *
 * - 토큰은 localStorage 에 둔다. LAN 안의 직원 PC 전용이라는 전제.
 * - 401 이 오면 토큰을 버리고 로그인으로 되돌린다 (onUnauthorized).
 * - 서버 에러 본문은 {"detail": "..."} 형태다. 그 문구를 그대로 화면에 띄운다.
 */
import type {
  AppUser, FloorMapMeta, MapBundle, Poi, PoiAdmin, PoiCreate, PoiUpdate,
  Robot, TokenOut, Trip, TripEvent, TripMode, TripStatus, UserRole,
} from '../types'

export const API_BASE =
  (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, '') ||
  'http://localhost:8000'

const TOKEN_KEY = 'sbr.admin.token'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}
export function setToken(t: string | null): void {
  if (t) localStorage.setItem(TOKEN_KEY, t)
  else localStorage.removeItem(TOKEN_KEY)
}

/** 토큰이 죽었을 때 앱 전체가 반응할 수 있게 훅을 하나 걸어둔다. */
let onUnauthorized: (() => void) | null = null
export function setUnauthorizedHandler(fn: (() => void) | null): void {
  onUnauthorized = fn
}

export class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
    this.name = 'ApiError'
  }
}

async function request<T>(
  path: string,
  init: RequestInit & { auth?: boolean } = {},
): Promise<T> {
  const { auth = true, headers, ...rest } = init
  const h = new Headers(headers)
  if (!h.has('Content-Type') && rest.body) h.set('Content-Type', 'application/json')
  const token = getToken()
  if (auth && token) h.set('Authorization', `Bearer ${token}`)

  let res: Response
  try {
    res = await fetch(`${API_BASE}${path}`, { ...rest, headers: h })
  } catch {
    throw new ApiError(0, `서버에 연결할 수 없다 (${API_BASE}). API가 떠 있는지 확인할 것`)
  }

  if (res.status === 401) {
    setToken(null)
    onUnauthorized?.()
    throw new ApiError(401, '로그인이 필요하다')
  }
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`
    try {
      const body = await res.json()
      if (typeof body?.detail === 'string') detail = body.detail
      else if (Array.isArray(body?.detail)) {
        detail = body.detail
          .map((d: { loc?: string[]; msg?: string }) =>
            `${d.loc?.slice(1).join('.') ?? ''} ${d.msg ?? ''}`.trim())
          .join(' / ')
      }
    } catch { /* 본문이 JSON이 아니면 상태 코드만 쓴다 */ }
    throw new ApiError(res.status, detail)
  }
  if (res.status === 204) return undefined as T
  return (await res.json()) as T
}

const qs = (o: Record<string, string | number | boolean | undefined>) => {
  const p = new URLSearchParams()
  for (const [k, v] of Object.entries(o)) if (v !== undefined) p.set(k, String(v))
  const s = p.toString()
  return s ? `?${s}` : ''
}

export const api = {
  // ---------------------------------------------------------- meta
  health: () =>
    request<{ status: string; postgis: string }>('/health', { auth: false }),

  // ---------------------------------------------------------- 직원-로그인
  login: (email: string, password: string) =>
    request<TokenOut>('/auth/login', {
      auth: false,
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  me: () => request<AppUser>('/auth/me'),
  changePassword: (current_password: string, new_password: string) =>
    request<void>('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ current_password, new_password }),
    }),

  // ---------------------------------------------------------- 직원-계정관리
  listUsers: () => request<AppUser[]>('/users'),
  createUser: (body: {
    email: string; password: string; display_name: string
    role: UserRole; facility_id?: number | null
  }) => request<AppUser>('/users', { method: 'POST', body: JSON.stringify(body) }),
  deactivateUser: (id: number) => request<AppUser>(`/users/${id}`, { method: 'DELETE' }),

  // ---------------------------------------------------------- 지도
  listMaps: (activeOnly = false) =>
    request<FloorMapMeta[]>(`/maps${qs({ active_only: activeOnly })}`),
  getMap: (id: number) => request<FloorMapMeta>(`/maps/${id}`),
  bundle: (id: number) => request<MapBundle>(`/maps/${id}/bundle`),

  // ---------------------------------------------------------- 직원-목적지편집
  listPois: (mapId: number, allPois = false) =>
    request<Poi[]>(`/maps/${mapId}/pois${qs({ all_pois: allPois })}`, { auth: false }),
  listPoisAdmin: (mapId: number, includeInactive = true) =>
    request<PoiAdmin[]>(`/maps/${mapId}/pois/admin${qs({ include_inactive: includeInactive })}`),
  reorderPois: (mapId: number, items: { poi_id: number; display_order: number }[]) =>
    request<Poi[]>(`/maps/${mapId}/pois/order`, {
      method: 'PATCH',
      body: JSON.stringify({ items }),
    }),
  createPoi: (body: PoiCreate) =>
    request<PoiAdmin>('/pois', { method: 'POST', body: JSON.stringify(body) }),
  updatePoi: (id: number, body: PoiUpdate) =>
    request<PoiAdmin>(`/pois/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  hidePoi: (id: number) => request<PoiAdmin>(`/pois/${id}`, { method: 'DELETE' }),
  restorePoi: (id: number) => request<PoiAdmin>(`/pois/${id}/restore`, { method: 'POST' }),

  // ---------------------------------------------------------- 직원-로봇상태
  listRobots: () => request<Robot[]>('/robots'),
  getRobot: (id: number) => request<Robot>(`/robots/${id}`),

  // ---------------------------------------------------------- 직원-안내이력 / 대리요청 / 원격취소
  listTrips: (o: { robot_id?: number; include_simulated?: boolean; limit?: number } = {}) =>
    request<Trip[]>(`/trips${qs(o)}`),
  createTrip: (body: {
    robot_id: number; mode: TripMode
    dest_poi_id?: number | null; origin_poi_id?: number | null
    requested_by?: 'kiosk' | 'dashboard' | 'robot_auto'
    is_simulated?: boolean
  }) => request<Trip>('/trips', { method: 'POST', body: JSON.stringify(body) }),
  updateTrip: (id: number, body: {
    status?: TripStatus; actual_distance_m?: number; abort_reason?: string
  }) => request<Trip>(`/trips/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  listTripEvents: (id: number) => request<TripEvent[]>(`/trips/${id}/events`),
}
