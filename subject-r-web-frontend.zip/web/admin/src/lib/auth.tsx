/** `직원-로그인` / `시스템-권한관리` — 토큰과 현재 사용자를 앱 전체에 공급한다. */
import {
  createContext, useCallback, useContext, useEffect, useMemo, useState,
  type ReactNode,
} from 'react'
import { api, getToken, setToken, setUnauthorizedHandler } from './api'
import type { AppUser, UserRole } from '../types'

const RANK: Record<UserRole, number> = { viewer: 1, staff: 2, admin: 3 }

interface AuthValue {
  user: AppUser | null
  ready: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  /** deps.py 의 require_role 과 같은 위계를 화면에서도 쓴다. */
  can: (minimum: UserRole) => boolean
}

const Ctx = createContext<AuthValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null)
  const [ready, setReady] = useState(false)

  const logout = useCallback(() => {
    setToken(null)
    setUser(null)
  }, [])

  useEffect(() => {
    setUnauthorizedHandler(() => setUser(null))
    return () => setUnauthorizedHandler(null)
  }, [])

  // 새로고침해도 로그인이 유지되도록 저장된 토큰을 한 번 검증한다.
  useEffect(() => {
    let alive = true
    const boot = async () => {
      if (!getToken()) { setReady(true); return }
      try {
        const me = await api.me()
        if (alive) setUser(me)
      } catch {
        setToken(null)
      } finally {
        if (alive) setReady(true)
      }
    }
    void boot()
    return () => { alive = false }
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    const t = await api.login(email, password)
    setToken(t.access_token)
    setUser(t.user)
  }, [])

  const can = useCallback(
    (minimum: UserRole) => !!user && RANK[user.role] >= RANK[minimum],
    [user],
  )

  const value = useMemo<AuthValue>(
    () => ({ user, ready, login, logout, can }),
    [user, ready, login, logout, can],
  )
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth(): AuthValue {
  const v = useContext(Ctx)
  if (!v) throw new Error('AuthProvider 밖에서 useAuth를 썼다')
  return v
}
