/** 표시용 변환.  DB·API는 전부 UTC다.  KST 변환은 여기서만 한다. */
import type {
  PoiCategory, RobotStatus, TripEventType, TripMode, TripRequester, TripStatus, UserRole,
} from '../types'

const KST = 'Asia/Seoul'

export function kstDateTime(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('ko-KR', {
    timeZone: KST, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false,
  })
}

export function kstTime(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleTimeString('ko-KR', {
    timeZone: KST, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  })
}

export function kstDate(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('ko-KR', {
    timeZone: KST, year: 'numeric', month: '2-digit', day: '2-digit',
  })
}

/** "3분 전" 같은 상대 시각.  대시보드에서 last_seen_at 이 언제인지 한눈에 보려고 쓴다. */
export function sinceNow(iso: string | null | undefined): string {
  if (!iso) return '기록 없음'
  const sec = Math.floor((Date.now() - new Date(iso).getTime()) / 1000)
  if (sec < 0) return '방금'
  if (sec < 10) return '방금'
  if (sec < 60) return `${sec}초 전`
  if (sec < 3600) return `${Math.floor(sec / 60)}분 전`
  if (sec < 86400) return `${Math.floor(sec / 3600)}시간 전`
  return `${Math.floor(sec / 86400)}일 전`
}

export function durationText(from: string | null, to: string | null): string {
  if (!from || !to) return '—'
  const sec = Math.round((new Date(to).getTime() - new Date(from).getTime()) / 1000)
  if (sec < 60) return `${sec}초`
  const m = Math.floor(sec / 60)
  const s = sec % 60
  return s ? `${m}분 ${s}초` : `${m}분`
}

export const meters = (v: number | null | undefined) =>
  v === null || v === undefined ? '—' : `${v.toFixed(1)} m`

export const TRIP_STATUS_KO: Record<TripStatus, string> = {
  requested: '요청됨',
  navigating: '안내 중',
  paused: '멈춤',
  arrived: '도착',
  completed: '완료',
  canceled: '취소',
  failed: '실패',
}

/** 상태별 색 계열.  CSS 의 .pill--{tone} 과 맞춘다. */
export const TRIP_STATUS_TONE: Record<TripStatus, string> = {
  requested: 'info',
  navigating: 'active',
  paused: 'warn',
  arrived: 'ok',
  completed: 'ok',
  canceled: 'muted',
  failed: 'bad',
}

export const ROBOT_STATUS_KO: Record<RobotStatus, string> = {
  offline: '연결 끊김',
  idle: '대기',
  driving: '주행 중',
  charging: '충전 중',
  error: '오류',
  estop: '비상정지',
}

export const ROBOT_STATUS_TONE: Record<RobotStatus, string> = {
  offline: 'muted',
  idle: 'ok',
  driving: 'active',
  charging: 'info',
  error: 'bad',
  estop: 'bad',
}

export const TRIP_MODE_KO: Record<TripMode, string> = {
  guide: '안내',
  follow: '따라오기',
  manual: '수동',
  return_to_charge: '충전 복귀',
}

export const REQUESTER_KO: Record<TripRequester, string> = {
  kiosk: '키오스크',
  dashboard: '대시보드',
  robot_auto: '로봇 자동',
}

export const ROLE_KO: Record<UserRole, string> = {
  admin: '관리자',
  staff: '직원',
  viewer: '조회 전용',
}

export const CATEGORY_KO: Record<PoiCategory, string> = {
  entrance: '출입구',
  lobby: '로비',
  restroom: '화장실',
  elevator: '엘리베이터',
  stairs: '계단',
  therapy_room: '치료실',
  program_room: '프로그램실',
  office: '사무실',
  cafeteria: '식당',
  charging_station: '충전 스테이션',
  waiting_area: '대기 공간',
  other: '기타',
}

export const EVENT_KO: Record<TripEventType, string> = {
  obstacle_detected: '장애물 발견',
  obstacle_cleared: '장애물 해소',
  replan: '경로 재계산',
  estop_pressed: '비상정지 눌림',
  estop_released: '비상정지 해제',
  manual_override: '수동 개입',
  paused: '일시정지',
  resumed: '재개',
  waypoint_reached: '경유지 통과',
  arrived: '도착',
  low_battery: '배터리 부족',
  localization_lost: '위치 추정 실패',
  error: '오류',
}

/** severity 0~3 을 색으로.  DB에 정의는 없지만 관례로 0=정보 … 3=심각. */
export function severityTone(sev: number): string {
  if (sev >= 3) return 'bad'
  if (sev === 2) return 'warn'
  if (sev === 1) return 'info'
  return 'muted'
}

export const TRIP_DONE: TripStatus[] = ['completed', 'arrived']
export const TRIP_LIVE: TripStatus[] = ['requested', 'navigating', 'paused']
