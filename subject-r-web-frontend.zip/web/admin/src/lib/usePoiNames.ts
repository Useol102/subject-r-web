/**
 * poi_id -> 이름 변환기.
 *
 * 목록 API(`GET /maps/{id}/pois`)는 **숨긴 목적지를 빼고** 준다.
 * 그런데 과거 안내 기록에는 지금은 숨긴 목적지가 그대로 남아 있다.
 * 그래서 권한이 있으면 관리자용 목록(숨긴 것 포함)을 쓰고, 없으면 공개 목록으로 떨어진다.
 */
import { useMemo } from 'react'
import { api } from './api'
import { useAuth } from './auth'
import { usePolling } from './usePolling'

export function usePoiNames(mapId: number | null): (id: number | null) => string {
  const { can } = useAuth()
  const staff = can('staff')

  const q = usePolling<{ id: number; name_ko: string }[]>(
    () => {
      if (!mapId) return Promise.resolve([])
      const p = staff
        ? api.listPoisAdmin(mapId, true)
        : api.listPois(mapId, true)
      return p.then((rows) => rows.map((r) => ({ id: r.id, name_ko: r.name_ko })))
    },
    [mapId, staff],
    null,
  )

  return useMemo(() => {
    const m = new Map<number, string>()
    for (const p of q.data ?? []) m.set(p.id, p.name_ko)
    return (id: number | null) => (id === null ? '—' : m.get(id) ?? `목적지 #${id}`)
  }, [q.data])
}
