/**
 * "지금 보고 있는 지도" 를 앱 전체가 공유한다.
 *
 * map 은 SLAM 을 다시 돌릴 때마다 새 버전 레코드가 생긴다.
 * 대부분의 화면은 활성 지도 하나만 보면 되지만, 과거 이력을 볼 때는
 * 그때 쓰던 지도로 바꿔야 좌표가 맞다. 그래서 선택 상태를 여기 둔다.
 */
import {
  createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode,
  type ChangeEvent,
} from 'react'
import { api } from './api'
import type { FloorMapMeta } from '../types'

const ENV_MAP_ID = Number(import.meta.env.VITE_MAP_ID ?? '') || null

interface MapCtx {
  maps: FloorMapMeta[]
  mapId: number | null
  map: FloorMapMeta | null
  setMapId: (id: number) => void
  loading: boolean
  error: string | null
  reload: () => void
}

const Ctx = createContext<MapCtx | null>(null)

export function MapProvider({ children }: { children: ReactNode }) {
  const [maps, setMaps] = useState<FloorMapMeta[]>([])
  const [mapId, setMapId] = useState<number | null>(ENV_MAP_ID)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    let alive = true
    setLoading(true)
    api.listMaps()
      .then((ms) => {
        if (!alive) return
        setMaps(ms)
        setError(null)
        setMapId((cur) => {
          if (cur && ms.some((m) => m.id === cur)) return cur
          return ms.find((m) => m.is_active)?.id ?? ms[0]?.id ?? null
        })
      })
      .catch((e) => alive && setError(e instanceof Error ? e.message : String(e)))
      .finally(() => alive && setLoading(false))
    return () => { alive = false }
  }, [tick])

  const value = useMemo<MapCtx>(() => ({
    maps,
    mapId,
    map: maps.find((m) => m.id === mapId) ?? null,
    setMapId,
    loading,
    error,
    reload: () => setTick((t) => t + 1),
  }), [maps, mapId, loading, error])

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useMaps(): MapCtx {
  const v = useContext(Ctx)
  if (!v) throw new Error('MapProvider 밖에서 useMaps를 썼다')
  return v
}

/** 상단바에 두는 지도 선택 드롭다운. */
export function MapPicker() {
  const { maps, mapId, setMapId } = useMaps()
  const onChange = useCallback(
    (e: ChangeEvent<HTMLSelectElement>) => setMapId(Number(e.target.value)),
    [setMapId],
  )
  if (maps.length <= 1) return null
  return (
    <select value={mapId ?? ''} onChange={onChange} style={{ width: 'auto' }}
            title="지도 버전 선택">
      {maps.map((m) => (
        <option key={m.id} value={m.id}>
          {m.floor}층 · {m.name ?? `v${m.version}`}{m.is_active ? ' (활성)' : ''}
        </option>
      ))}
    </select>
  )
}
