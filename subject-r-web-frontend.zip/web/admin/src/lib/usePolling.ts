/**
 * 폴링 훅.
 *
 * `직원-실시간위치` 는 원래 WebSocket + pose_log 로 가야 하는데
 * 로그 발행 주기(Hz)가 아직 안 정해져서 pose_log 테이블이 없다.
 * 그동안은 REST를 주기적으로 다시 읽어 대신한다.
 *
 * WebSocket이 생기면 이 훅을 쓰는 화면만 갈아끼우면 된다.
 */
import { useCallback, useEffect, useRef, useState } from 'react'

export const POLL_MS = Number(import.meta.env.VITE_POLL_MS ?? 3000)

export interface PollState<T> {
  data: T | null
  error: string | null
  loading: boolean
  /** 마지막으로 성공한 시각 (ms). 화면에 "N초 전 갱신"으로 쓴다. */
  updatedAt: number | null
  refresh: () => void
}

export function usePolling<T>(
  fetcher: () => Promise<T>,
  deps: unknown[] = [],
  intervalMs: number | null = POLL_MS,
): PollState<T> {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [updatedAt, setUpdatedAt] = useState<number | null>(null)
  const [tick, setTick] = useState(0)
  const alive = useRef(true)
  // deps 배열의 내용을 문자열로 굳혀서 useEffect 의존성으로 쓴다.
  const depKey = JSON.stringify(deps)

  const refresh = useCallback(() => setTick((t) => t + 1), [])

  useEffect(() => {
    alive.current = true
    let timer: number | undefined

    const run = async () => {
      try {
        const v = await fetcher()
        if (!alive.current) return
        setData(v)
        setError(null)
        setUpdatedAt(Date.now())
      } catch (e) {
        if (!alive.current) return
        setError(e instanceof Error ? e.message : String(e))
      } finally {
        if (alive.current) setLoading(false)
      }
    }

    void run()
    if (intervalMs && intervalMs > 0) {
      timer = window.setInterval(run, intervalMs)
    }
    return () => {
      alive.current = false
      if (timer) window.clearInterval(timer)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [depKey, intervalMs, tick])

  return { data, error, loading, updatedAt, refresh }
}
