/**
 * `직원-히트맵` — 장애물이 자주 잡히는 지점.
 *
 * 서버 집계가 없어서 최근 안내 N건의 `GET /trips/{id}/events` 를 하나씩 불러
 * 좌표가 있는 사건만 모아 격자에 담는다. 요청 수가 곧 N이라 상한을 둔다.
 * 서버에 `GET /stats/hotspots` 가 생기면 이 화면은 그걸 그리기만 하면 된다.
 */
import { useEffect, useMemo, useState } from 'react'
import { api } from '../lib/api'
import { useMaps, MapPicker } from '../lib/mapctx'
import { EVENT_KO } from '../lib/format'
import { FloorMap, type MapPoint } from '../components/FloorMap'
import { Banner, Bar, Empty, Loading } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { MapBundle, TripEvent, TripEventType } from '../types'

/** 사건을 이 격자 크기(m)로 뭉쳐서 "다발 지점" 으로 본다. */
const CELL_M = 1.0
const SCAN_LIMITS = [20, 40, 80]

const WATCH: TripEventType[] = [
  'obstacle_detected', 'replan', 'estop_pressed', 'localization_lost', 'error',
]

interface Cell { x: number; y: number; n: number; kinds: Map<TripEventType, number> }

export function Heatmap() {
  const { map, mapId } = useMaps()
  const [scan, setScan] = useState(40)
  const [kinds, setKinds] = useState<TripEventType[]>(WATCH)
  const [rows, setRows] = useState<{ ev: TripEvent; tripId: number }[]>([])
  const [bundle, setBundle] = useState<MapBundle | null>(null)
  const [busy, setBusy] = useState(true)
  const [err, setErr] = useState<string | null>(null)
  const [scanned, setScanned] = useState(0)

  useEffect(() => {
    if (!mapId) return
    let alive = true
    setBusy(true); setErr(null); setRows([]); setScanned(0)

    const run = async () => {
      try {
        const b = await api.bundle(mapId)
        if (!alive) return
        setBundle(b)

        const trips = (await api.listTrips({ limit: scan, include_simulated: false }))
          .filter((t) => t.map_id === mapId)
        const out: { ev: TripEvent; tripId: number }[] = []
        // 순차로 돈다. 동시에 40개를 던지면 개발용 uvicorn 이 버거워한다.
        for (const t of trips) {
          if (!alive) return
          try {
            const evs = await api.listTripEvents(t.id)
            for (const e of evs) if (e.x !== null && e.y !== null) out.push({ ev: e, tripId: t.id })
          } catch { /* 한 건 실패는 무시하고 계속 */ }
          setScanned((n) => n + 1)
        }
        if (alive) setRows(out)
      } catch (e) {
        if (alive) setErr(e instanceof Error ? e.message : String(e))
      } finally {
        if (alive) setBusy(false)
      }
    }
    void run()
    return () => { alive = false }
  }, [mapId, scan])

  const filtered = useMemo(
    () => rows.filter((r) => kinds.includes(r.ev.event_type)),
    [rows, kinds],
  )

  const cells = useMemo(() => {
    const m = new Map<string, Cell>()
    for (const { ev } of filtered) {
      const cx = Math.floor((ev.x as number) / CELL_M) * CELL_M + CELL_M / 2
      const cy = Math.floor((ev.y as number) / CELL_M) * CELL_M + CELL_M / 2
      const k = `${cx},${cy}`
      const cur = m.get(k) ?? { x: cx, y: cy, n: 0, kinds: new Map() }
      cur.n += 1
      cur.kinds.set(ev.event_type, (cur.kinds.get(ev.event_type) ?? 0) + 1)
      m.set(k, cur)
    }
    return [...m.values()].sort((a, b) => b.n - a.n)
  }, [filtered])

  const maxN = Math.max(1, ...cells.map((c) => c.n))
  const points = useMemo<MapPoint[]>(() => cells.map((c) => ({
    x: c.x, y: c.y,
    weight: (c.n / maxN) * 4,
    tone: c.n / maxN > 0.6 ? 'bad' : c.n / maxN > 0.3 ? 'warn' : 'info',
    label: `${c.n}건 — ${[...c.kinds.entries()].map(([k, v]) => `${EVENT_KO[k]} ${v}`).join(', ')}`,
  })), [cells, maxN])

  const byKind = useMemo(() => {
    const m = new Map<TripEventType, number>()
    for (const { ev } of rows) m.set(ev.event_type, (m.get(ev.event_type) ?? 0) + 1)
    return [...m.entries()].sort((a, b) => b[1] - a[1])
  }, [rows])

  return (
    <>
      <PageHead
        title="장애물 다발 지점"
        sub={`최근 안내 ${scan}건에서 좌표가 있는 사건을 ${CELL_M}m 격자로 묶었다`}
        right={<>
          <MapPicker />
          <select value={scan} style={{ width: 'auto' }}
                  onChange={(e) => setScan(Number(e.target.value))}>
            {SCAN_LIMITS.map((n) => <option key={n} value={n}>최근 {n}건 조사</option>)}
          </select>
        </>}
      />

      <div className="page stack">
        <Banner tone="warn">
          <span>◔</span>
          <div>
            서버 집계(<code>직원-히트맵</code>)가 없어서 <b>안내 {scan}건의 사건을 한 건씩 불러</b>
            브라우저에서 묶은 값이다. 기록이 많아지면 느려진다 —
            <code>trip_event.geom</code> 을 PostGIS 로 집계하는 API가 생기면 그쪽으로 옮긴다.
          </div>
        </Banner>

        {err ? <Banner tone="bad">{err}</Banner> : null}
        {busy ? <Loading label={`사건을 모으는 중 ${scanned}/${scan}`} /> : null}

        {!busy && map ? (
          <div className="grid grid--main">
            <div className="card">
              <div className="card__head">
                <h3>지도</h3>
                <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
                  {cells.length}개 지점 · 사건 {filtered.length}건
                </span>
              </div>
              {bundle ? (
                <FloorMap map={map} pois={bundle.pois} zones={bundle.zones}
                          points={points} tall />
              ) : null}
            </div>

            <div className="stack">
              <div className="card">
                <div className="card__head"><h3>사건 종류</h3></div>
                <div className="card__body">
                  <div className="stack--sm">
                    {WATCH.map((k) => (
                      <label className="checkline" key={k}>
                        <input type="checkbox" checked={kinds.includes(k)}
                               onChange={(e) => setKinds((s) =>
                                 e.target.checked ? [...s, k] : s.filter((v) => v !== k))} />
                        {EVENT_KO[k]}
                        <span className="muted mono" style={{ marginLeft: 'auto' }}>
                          {byKind.find(([t]) => t === k)?.[1] ?? 0}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="card__head"><h3>상위 지점</h3></div>
                <div className="card__body">
                  {cells.length === 0 ? (
                    <Empty icon="✓">모인 사건이 없다</Empty>
                  ) : (
                    <div className="bars">
                      {cells.slice(0, 10).map((c) => (
                        <Bar key={`${c.x},${c.y}`}
                             name={`(${c.x.toFixed(1)}, ${c.y.toFixed(1)}) m`}
                             value={c.n} max={maxN} text={`${c.n}건`}
                             bad={c.n / maxN > 0.6} />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </>
  )
}
