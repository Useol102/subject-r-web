/** `직원-안내이력` — 날짜별 목록, 성공/실패 필터. */
import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../lib/api'
import { useMaps } from '../lib/mapctx'
import { usePolling } from '../lib/usePolling'
import { usePoiNames } from '../lib/usePoiNames'
import {
  durationText, kstDate, kstTime, meters, REQUESTER_KO,
  TRIP_MODE_KO, TRIP_STATUS_KO, TRIP_STATUS_TONE,
} from '../lib/format'
import { Banner, Empty, Loading, Pill } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { Robot, Trip, TripStatus } from '../types'

type Filter = 'all' | 'live' | 'done' | 'bad'

const FILTERS: { key: Filter; label: string; match: (s: TripStatus) => boolean }[] = [
  { key: 'all',  label: '전체',    match: () => true },
  { key: 'live', label: '진행 중', match: (s) => ['requested', 'navigating', 'paused'].includes(s) },
  { key: 'done', label: '완료',    match: (s) => s === 'completed' || s === 'arrived' },
  { key: 'bad',  label: '취소·실패', match: (s) => s === 'canceled' || s === 'failed' },
]

export function Trips() {
  const nav = useNavigate()
  const { mapId } = useMaps()
  const [filter, setFilter] = useState<Filter>('all')
  const [robotId, setRobotId] = useState<number | ''>('')
  const [withSim, setWithSim] = useState(true)
  const [limit, setLimit] = useState(50)
  const [q, setQ] = useState('')

  const robots = usePolling<Robot[]>(() => api.listRobots(), [], null)
  const trips = usePolling<Trip[]>(
    () => api.listTrips({
      limit,
      include_simulated: withSim,
      robot_id: robotId === '' ? undefined : Number(robotId),
    }),
    [limit, withSim, robotId],
  )

  const poiName = usePoiNames(mapId)

  const robotName = useMemo(() => {
    const m = new Map<number, string>()
    for (const r of robots.data ?? []) m.set(r.id, r.name)
    return (id: number) => m.get(id) ?? `로봇 ${id}`
  }, [robots.data])

  const rows = useMemo(() => {
    const f = FILTERS.find((x) => x.key === filter)!
    const needle = q.trim()
    return (trips.data ?? [])
      .filter((t) => f.match(t.status))
      .filter((t) => !needle
        || String(t.id) === needle
        || poiName(t.dest_poi_id).includes(needle)
        || t.uuid.startsWith(needle))
  }, [trips.data, filter, q, poiName])

  /** 날짜(KST)별로 묶는다. 직원이 "어제 몇 건" 을 눈으로 세기 쉽게. */
  const groups = useMemo(() => {
    const g = new Map<string, Trip[]>()
    for (const t of rows) {
      const d = kstDate(t.requested_at)
      if (!g.has(d)) g.set(d, [])
      g.get(d)!.push(t)
    }
    return [...g.entries()]
  }, [rows])

  return (
    <>
      <PageHead
        title="안내 이력"
        sub={`최근 ${limit}건 · ${rows.length}건 표시 중`}
        right={
          <button className="btn btn--sm" onClick={trips.refresh}>새로고침</button>
        }
      />
      <div className="page stack">
        <div className="card">
          <div className="card__body">
            <div className="toolbar">
              <div style={{ display: 'flex', gap: 4 }}>
                {FILTERS.map((f) => (
                  <button key={f.key}
                          className={`btn btn--sm${filter === f.key ? ' btn--primary' : ''}`}
                          onClick={() => setFilter(f.key)}>
                    {f.label}
                  </button>
                ))}
              </div>
              <select value={robotId} style={{ width: 'auto' }}
                      onChange={(e) => setRobotId(e.target.value === '' ? '' : Number(e.target.value))}>
                <option value="">모든 로봇</option>
                {(robots.data ?? []).map((r) => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
              <select value={limit} style={{ width: 'auto' }}
                      onChange={(e) => setLimit(Number(e.target.value))}>
                {[25, 50, 100, 200].map((n) => <option key={n} value={n}>최근 {n}건</option>)}
              </select>
              <label className="checkline">
                <input type="checkbox" checked={withSim}
                       onChange={(e) => setWithSim(e.target.checked)} />
                시뮬레이션 포함
              </label>
              <input className="grow" type="search" placeholder="번호 · 목적지 이름 검색"
                     value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>
        </div>

        {trips.error ? <Banner tone="bad">{trips.error}</Banner> : null}
        {trips.loading && !trips.data ? <Loading /> : null}
        {!trips.loading && rows.length === 0 ? (
          <div className="card"><Empty icon="≡">조건에 맞는 안내가 없다</Empty></div>
        ) : null}

        {groups.map(([date, list]) => (
          <div className="card" key={date}>
            <div className="card__head">
              <h3>{date}</h3>
              <span className="spacer" />
              <span className="muted" style={{ fontSize: 12, marginLeft: 'auto' }}>
                {list.length}건 · 완료 {list.filter((t) => t.status === 'completed').length} ·
                {' '}실패·취소 {list.filter((t) => t.status === 'failed' || t.status === 'canceled').length}
              </span>
            </div>
            <div className="card__body--flush">
              <table className="tbl">
                <thead>
                  <tr>
                    <th style={{ width: 62 }}>번호</th>
                    <th style={{ width: 96 }}>상태</th>
                    <th>목적지</th>
                    <th style={{ width: 96 }}>유형</th>
                    <th style={{ width: 110 }}>로봇</th>
                    <th style={{ width: 96 }}>요청</th>
                    <th style={{ width: 78 }}>시작</th>
                    <th style={{ width: 78 }}>소요</th>
                    <th style={{ width: 92 }} className="right">이동거리</th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((t) => (
                    <tr key={t.id}
                        className={`row--link${t.is_simulated ? ' row--dim' : ''}`}
                        onClick={() => nav(`/trips/${t.id}`)}>
                      <td className="mono">#{t.id}</td>
                      <td><Pill tone={TRIP_STATUS_TONE[t.status]}>{TRIP_STATUS_KO[t.status]}</Pill></td>
                      <td>
                        {poiName(t.dest_poi_id)}
                        {t.abort_reason ? (
                          <div className="muted" style={{ fontSize: 11.5 }}>{t.abort_reason}</div>
                        ) : null}
                      </td>
                      <td>
                        {TRIP_MODE_KO[t.mode]}
                        {t.is_simulated ? <span className="muted"> · 시뮬</span> : null}
                      </td>
                      <td className="nowrap">{robotName(t.robot_id)}</td>
                      <td className="nowrap">{REQUESTER_KO[t.requested_by]}</td>
                      <td className="mono nowrap">{kstTime(t.started_at ?? t.requested_at).slice(0, 5)}</td>
                      <td className="nowrap">{durationText(t.started_at, t.ended_at)}</td>
                      <td className="num">{meters(t.actual_distance_m ?? t.planned_distance_m)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
