/** `직원-로그인` */
import { useEffect, useState, type FormEvent } from 'react'
import { api, API_BASE } from '../lib/api'
import { useAuth } from '../lib/auth'

export function Login() {
  const { login } = useAuth()
  const [email, setEmail] = useState('')
  const [pw, setPw] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const [health, setHealth] = useState<'checking' | 'up' | 'down'>('checking')

  // 로그인 실패가 "비밀번호가 틀려서"인지 "서버가 안 떠서"인지 미리 구분해준다.
  useEffect(() => {
    let alive = true
    api.health()
      .then(() => alive && setHealth('up'))
      .catch(() => alive && setHealth('down'))
    return () => { alive = false }
  }, [])

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setErr(null)
    try {
      await login(email.trim(), pw)
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : String(e2))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="login-wrap">
      <div className="login">
        <div className="login__mark">SbR</div>
        <h1>Subject R 관리자</h1>
        <p className="sub">베리어프리 안내 로봇 · 직원용 대시보드</p>

        <form className="card" onSubmit={submit}>
          <div className="card__body">
            {health === 'down' ? (
              <div className="banner banner--bad">
                <span>⚠</span>
                <div>
                  API 서버에 연결되지 않는다.<br />
                  <code>{API_BASE}</code> 에서 <code>uvicorn app.main:app --reload</code> 가
                  떠 있는지 확인할 것.
                </div>
              </div>
            ) : null}

            <div className="field">
              <label htmlFor="email">이메일</label>
              <input id="email" type="email" autoComplete="username" required
                     value={email} onChange={(e) => setEmail(e.target.value)}
                     placeholder="staff@example.org" autoFocus />
            </div>

            <div className="field">
              <label htmlFor="pw">비밀번호</label>
              <input id="pw" type="password" autoComplete="current-password" required
                     value={pw} onChange={(e) => setPw(e.target.value)} />
            </div>

            {err ? <div className="banner banner--bad"><span>✕</span><div>{err}</div></div> : null}

            <button className="btn btn--primary btn--block" disabled={busy || !email || !pw}>
              {busy ? <span className="spin" /> : null}
              {busy ? '확인 중' : '로그인'}
            </button>
          </div>
        </form>

        <div className="login__foot">
          첫 관리자 계정은 서버에서 만든다:<br />
          <code>.\.venv\Scripts\python.exe tools\create_admin.py</code>
        </div>
      </div>
    </div>
  )
}
