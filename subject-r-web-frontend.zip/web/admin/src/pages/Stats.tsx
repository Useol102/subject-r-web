/**
 * `직원-안내통계`
 *
 * 서버에 집계 API가 없다. `GET /trips` 로 받아온 목록을 브라우저에서 센다.
 * 그래서 **최근 N건 범위 안에서만** 정확하다 — 화면에도 그렇게 적어둔다.
 * 나중에 `GET /stats/trips` 가 생기면 이 파일의 집계 부분만 걷어내면 된다.
 */
import { useMemo, useState } from 'react'
import { api } from '../lib/api'
import { useMaps } from '../lib/mapctx'
import { usePolling } from '../lib/usePolling'
import { usePoiNames } from '../lib/usePoiNames'
import { kstDate, REQUESTER_KO, TRIP_STATUS_KO } from '../lib/format'
import { Bar, Banner, Empty, Loading, Stat } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { Trip, TripRequester, TripStatus } from '../types'

const LIMITS = [50, 100, 200, 500]

/** 시간대 막대의 최대 높이(px). 퍼센트로 주면 부모 높이가 auto라 무너진다. */
const HOUR_CHART_H = 110

/** 결과 구성 막대의 색. 상태색은 계열 색으로 돌려쓰지 않는다. */
const OUTCOME: { key: TripStatus[]; label: string; varName: string }[] = [
  { key: ['completed', 'arrived'], label: '완료', varName: '--ok' },
  { key: ['canceled'],             label: '취소', varName: '--muted' },
  { key: ['failed'],               label: '실패', varName: '--bad' },
  { key: ['requested', 'navigating', 'paused'], label: '진행 중', varName: '--active' },
]

export function Stats() {
  const { mapId } = useMaps()
  const [limit, setLimit] = useState(200)
  const [withSim, setWithSim] = useState(false)

  const trips = usePolling<Trip[]>(
    () => api.listTrips({ limit, include_simulated: withSim }), [limit, withSim], null,
  )

  const data = trips.data ?? []

  const poiName = usePoiNames(mapId)

  const outcome = useMemo(() => OUTCOME.map((o) => ({
    ...o, n: data.filter((t) => o.key.includes(t.status)).length,
  })), [data])

  const finished = data.filter((t) =>
    ['completed', 'arrived', 'canceled', 'failed'].includes(t.status))
  const succeeded = data.filter((t) => t.status === 'completed' || t.status === 'arrived')
  const successRate = finished.length ? (succeeded.length / finished.length) * 100 : null

  const avgSec = useMemo(() => {
    const xs = succeeded
      .filter((t) => t.started_at && t.ended_at)
      .map((t) => (new Date(t.ended_at!).getTime() - new Date(t.started_at!).getTime()) / 1000)
    return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null
  }, [succeeded])

  const avgDist = useMemo(() => {
    const xs = succeeded.map((t) => t.actual_distance_m).filter((v): v is number => v !== null)
    return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null
  }, [succeeded])

  /** 목적지별 건수 — 크기 비교라서 가로 막대. 많은 순으로 정렬한다. */
  const byDest = useMemo(() => {
    const m = new Map<string, { n: number; bad: number }>()
    for (const t of data) {
      const k = poiName(t.dest_poi_id)
      const cur = m.get(k) ?? { n: 0, bad: 0 }
      cur.n += 1
      if (t.status === 'failed' || t.status === 'canceled') cur.bad += 1
      m.set(k, cur)
    }
    return [...m.entries()].sort((a, b) => b[1].n - a[1].n).slice(0, 12)
  }, [data, poiName])

  /** 시간대별 — 어느 시간에 사람이 몰리는지. 09~18시가 복지관 운영시간. */
  const byHour = useMemo(() => {
    const buckets = Array.from({ length: 24 }, () => 0)
    for (const t of data) {
      const h = Number(new Date(t.requested_at).toLocaleString('en-US', {
        timeZone: 'Asia/Seoul', hour: '2-digit', hour12: false,
      }))
      buckets[h % 24] += 1
    }
    return buckets
  }, [data])

  const byRequester = useMemo(() => {
    const m = new Map<TripRequester, number>()
    for (const t of data) m.set(t.requested_by, (m.get(t.requested_by) ?? 0) + 1)
    return [...m.entries()].sort((a, b) => b[1] - a[1])
  }, [data])

  const aborts = useMemo(() => {
    const m = new Map<string, number>()
    for (const t of data) {
      if (!t.abort_reason) continue
      m.set(t.abort_reason, (m.get(t.abort_reason) ?? 0) + 1)
    }
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8)
  }, [data])

  const span = data.length
    ? `${kstDate(data[data.length - 1].requested_at)} ~ ${kstDate(data[0].requested_at)}`
    : '—'
  const maxDest = Math.max(1, ...byDest.map(([, v]) => v.n))
  const maxHour = Math.max(1, ...byHour)
  const total = Math.max(1, data.length)

  return (
    <>
      <PageHead
        title="안내 통계"
        sub={`최근 ${limit}건 · ${span}`}
        right={<>
          <select value={limit} style={{ width: 'auto' }}
                  onChange={(e) => setLimit(Number(e.target.value))}>
            {LIMITS.map((n) => <option key={n} value={n}>최근 {n}건</option>)}
          </select>
          <label className="checkline">
            <input type="checkbox" checked={withSim}
                   onChange={(e) => setWithSim(e.target.checked)} />
            시뮬레이션 포함
          </label>
        </>}
      />

      <div className="page stack">
        <Banner tone="info">
          <span>ⓘ</span>
          <div>
            서버에 집계 API(<code>직원-안내통계</code>)가 아직 없어서, <code>GET /trips</code>로
            받아온 <b>최근 {limit}건만</b> 브라우저에서 센 값이다. 기간 전체 통계가 필요하면
            서버 집계를 먼저 만들어야 한다.
          </div>
        </Banner>

        {trips.loading && !trips.data ? <Loading /> : null}
        {!trips.loading && data.length === 0 ? (
          <div className="card"><Empty icon="▤">집계할 안내 기록이 없다</Empty></div>
        ) : null}

        {data.length ? (
          <>
            <div className="grid grid--4">
              <Stat label="안내 건수" value={data.length} unit="건" foot={span} />
              <Stat
                label="성공률"
                value={successRate === null ? '—' : successRate.toFixed(0)}
                unit={successRate === null ? undefined : '%'}
                tone={successRate !== null && successRate < 80 ? 'bad' : 'ok'}
                foot={`끝난 ${finished.length}건 중 ${succeeded.length}건 완료`}
              />
              <Stat
                label="평균 소요"
                value={avgSec === null ? '—' : Math.round(avgSec / 60) >= 1
                  ? `${Math.floor(avgSec / 60)}:${String(Math.round(avgSec % 60)).padStart(2, '0')}`
                  : Math.round(avgSec)}
                unit={avgSec === null ? undefined : avgSec >= 60 ? '분:초' : '초'}
                foot="완료된 안내 기준"
              />
              <Stat
                label="평균 이동거리"
                value={avgDist === null ? '—' : avgDist.toFixed(1)}
                unit={avgDist === null ? undefined : 'm'}
                foot="actual_distance_m 기록분"
              />
            </div>

            <div className="grid grid--2">
              <div className="card">
                <div className="card__head"><h3>결과 구성</h3></div>
                <div className="card__body stack--sm">
                  <div className="split">
                    {outcome.filter((o) => o.n > 0).map((o, i, arr) => (
                      <i key={o.label}
                         title={`${o.label} ${o.n}건`}
                         style={{
                           width: `${(o.n / total) * 100}%`,
                           background: `var(${o.varName})`,
                           marginRight: i < arr.length - 1 ? 2 : 0,
                         }} />
                    ))}
                  </div>
                  <div className="maplegend" style={{ border: 0, padding: '6px 0 0' }}>
                    {outcome.map((o) => (
                      <span key={o.label}>
                        <i style={{ background: `var(${o.varName})` }} />
                        {o.label} <b style={{ fontVariantNumeric: 'tabular-nums' }}>{o.n}</b>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="card__head"><h3>요청 경로</h3></div>
                <div className="card__body">
                  <div className="bars">
                    {byRequester.map(([k, n]) => (
                      <Bar key={k} name={REQUESTER_KO[k]} value={n} max={data.length}
                           text={`${n}건`} />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card__head">
                <h3>목적지별 안내 건수</h3>
                <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
                  상위 {byDest.length}개 · 괄호 안은 취소·실패
                </span>
              </div>
              <div className="card__body">
                <div className="bars">
                  {byDest.map(([name, v]) => (
                    <Bar key={name} name={name} value={v.n} max={maxDest}
                         text={v.bad ? `${v.n} (${v.bad})` : `${v.n}`} />
                  ))}
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card__head">
                <h3>시간대별 요청 (KST)</h3>
                <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
                  가장 붐비는 시간 {byHour.indexOf(maxHour)}시
                </span>
              </div>
              <div className="card__body">
                <div style={{
                  display: 'grid', gridTemplateColumns: 'repeat(24, 1fr)', gap: 3,
                }}>
                  {byHour.map((n, h) => (
                    <div key={h} title={`${h}시 · ${n}건`}
                         style={{
                           display: 'flex', flexDirection: 'column',
                           justifyContent: 'flex-end', alignItems: 'stretch', gap: 5,
                         }}>
                      <div style={{ height: HOUR_CHART_H, display: 'flex', alignItems: 'flex-end' }}>
                        <div style={{
                          width: '100%',
                          height: Math.max(n ? 5 : 2, (n / maxHour) * HOUR_CHART_H),
                          background: n ? 'var(--brand)' : 'var(--line)',
                          borderRadius: '4px 4px 0 0',
                        }} />
                      </div>
                      <div style={{
                        fontSize: 10, textAlign: 'center', color: 'var(--text-3)',
                        fontVariantNumeric: 'tabular-nums',
                      }}>{h % 3 === 0 ? h : ''}</div>
                    </div>
                  ))}
                </div>
                <div className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>
                  가로축은 요청 시각(0~23시), 세로축은 건수. 가장 많은 시간이 {maxHour}건이다.
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card__head"><h3>중단 사유</h3></div>
              <div className="card__body">
                {aborts.length === 0 ? (
                  <Empty icon="✓">기록된 중단 사유가 없다</Empty>
                ) : (
                  <div className="bars">
                    {aborts.map(([reason, n]) => (
                      <Bar key={reason} name={reason} value={n}
                           max={Math.max(...aborts.map(([, v]) => v))} text={`${n}건`} bad />
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="card">
              <div className="card__head"><h3>상태별 원자료</h3></div>
              <div className="card__body--flush">
                <table className="tbl">
                  <thead><tr><th>상태</th><th className="right">건수</th><th className="right">비율</th></tr></thead>
                  <tbody>
                    {(Object.keys(TRIP_STATUS_KO) as TripStatus[]).map((s) => {
                      const n = data.filter((t) => t.status === s).length
                      return (
                        <tr key={s}>
                          <td>{TRIP_STATUS_KO[s]} <span className="muted mono">{s}</span></td>
                          <td className="num">{n}</td>
                          <td className="num">{((n / total) * 100).toFixed(1)}%</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </>
  )
}
