/** `직원-안내상세` — 경로와 사건 타임라인. */
import { useMemo, type ReactNode } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api } from '../lib/api'
import { useAuth } from '../lib/auth'
import { useMaps } from '../lib/mapctx'
import { usePolling } from '../lib/usePolling'
import { usePoiNames } from '../lib/usePoiNames'
import {
  durationText, EVENT_KO, kstDateTime, kstTime, meters, REQUESTER_KO,
  severityTone, TRIP_LIVE, TRIP_MODE_KO, TRIP_STATUS_KO, TRIP_STATUS_TONE,
} from '../lib/format'
import { FloorMap, type MapPoint } from '../components/FloorMap'
import { useToast } from '../components/Toast'
import { Banner, Empty, Loading, Pill } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { Trip, TripEvent } from '../types'

export function TripDetail() {
  const { id } = useParams()
  const tripId = Number(id)
  const { can } = useAuth()
  const { maps } = useMaps()
  const toast = useToast()

  // 목록 API만 있고 단건 조회가 없다. 넉넉히 받아서 골라 쓴다.
  const trips = usePolling<Trip[]>(() => api.listTrips({ limit: 200 }), [])
  const events = usePolling<TripEvent[]>(() => api.listTripEvents(tripId), [tripId])

  const trip = useMemo(
    () => (trips.data ?? []).find((t) => t.id === tripId) ?? null,
    [trips.data, tripId],
  )
  const map = useMemo(
    () => maps.find((m) => m.id === trip?.map_id) ?? null,
    [maps, trip],
  )
  const bundle = usePolling(
    () => (trip ? api.bundle(trip.map_id) : Promise.resolve(null)),
    [trip?.map_id], null,
  )

  const points = useMemo<MapPoint[]>(
    () => (events.data ?? [])
      .filter((e) => e.x !== null && e.y !== null)
      .map((e) => ({
        x: e.x as number, y: e.y as number,
        label: `${EVENT_KO[e.event_type]} · ${kstTime(e.ts)}`,
        tone: severityTone(e.severity) as MapPoint['tone'],
      })),
    [events.data],
  )
  const path = useMemo(
    () => points.map((p) => [p.x, p.y]),
    [points],
  )

  const poiName = usePoiNames(trip?.map_id ?? null)

  const cancel = async () => {
    if (!trip) return
    try {
      await api.updateTrip(trip.id, { status: 'canceled', abort_reason: '직원 원격 취소' })
      toast('취소했다')
      trips.refresh()
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true)
    }
  }

  if (trips.loading && !trip) return <><PageHead title="안내 상세" /><div className="page"><Loading /></div></>
  if (!trip) {
    return (
      <>
        <PageHead title="안내 상세" />
        <div className="page">
          <div className="card">
            <Empty icon="?">
              #{tripId} 을(를) 최근 200건에서 찾지 못했다.<br />
              <Link className="btn btn--sm" to="/trips" style={{ marginTop: 10 }}>목록으로</Link>
            </Empty>
          </div>
        </div>
      </>
    )
  }

  const isLive = TRIP_LIVE.includes(trip.status)

  return (
    <>
      <PageHead
        title={`안내 #${trip.id}`}
        sub={`${poiName(trip.origin_poi_id)} → ${poiName(trip.dest_poi_id)}`}
        right={<>
          <Pill tone={TRIP_STATUS_TONE[trip.status]}>{TRIP_STATUS_KO[trip.status]}</Pill>
          {isLive && can('staff') ? (
            <button className="btn btn--sm btn--danger" onClick={cancel}>원격 취소</button>
          ) : null}
          <Link className="btn btn--sm" to="/trips">목록</Link>
        </>}
      />

      <div className="page stack">
        <div className="grid grid--main">
          <div className="card">
            <div className="card__head">
              <h3>경로와 사건 위치</h3>
              <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
                좌표가 있는 사건 {points.length}건
              </span>
            </div>
            {map && bundle.data ? (
              <FloorMap
                map={map}
                pois={bundle.data.pois}
                zones={bundle.data.zones}
                points={points}
                path={path.length > 1 ? path : undefined}
                highlightPoiId={trip.dest_poi_id}
              />
            ) : <Loading label="지도를 불러오는 중" />}
            <div style={{ padding: '0 16px 14px' }}>
              <Banner tone="info">
                <span>ⓘ</span>
                <div>
                  점선은 <b>사건이 기록된 좌표를 이은 선</b>이지 실제 주행 궤적이 아니다.
                  진짜 궤적은 <code>pose_log</code>(<code>로봇-위치보고</code>)가 생겨야 그릴 수 있다.
                </div>
              </Banner>
            </div>
          </div>

          <div className="stack">
            <div className="card">
              <div className="card__head"><h3>요약</h3></div>
              <div className="card__body">
                <table className="tbl">
                  <tbody>
                    <Row k="상태"><Pill tone={TRIP_STATUS_TONE[trip.status]}>{TRIP_STATUS_KO[trip.status]}</Pill></Row>
                    <Row k="유형">{TRIP_MODE_KO[trip.mode]}{trip.is_simulated ? ' · 시뮬레이션' : ''}</Row>
                    <Row k="요청 경로">{REQUESTER_KO[trip.requested_by]}</Row>
                    <Row k="출발">{poiName(trip.origin_poi_id)}</Row>
                    <Row k="도착">{poiName(trip.dest_poi_id)}</Row>
                    <Row k="요청 시각">{kstDateTime(trip.requested_at)}</Row>
                    <Row k="시작">{kstDateTime(trip.started_at)}</Row>
                    <Row k="종료">{kstDateTime(trip.ended_at)}</Row>
                    <Row k="소요">{durationText(trip.started_at, trip.ended_at)}</Row>
                    <Row k="계획 거리">{meters(trip.planned_distance_m)}</Row>
                    <Row k="실제 거리">{meters(trip.actual_distance_m)}</Row>
                    {trip.abort_reason ? <Row k="중단 사유">{trip.abort_reason}</Row> : null}
                    <Row k="UUID"><span className="mono" style={{ fontSize: 11 }}>{trip.uuid}</span></Row>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card__head">
            <h3>사건 타임라인</h3>
            <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
              {events.data?.length ?? 0}건
            </span>
          </div>
          <div className="card__body">
            {events.loading && !events.data ? <Loading /> : null}
            {events.data?.length === 0 ? (
              <Empty icon="—">기록된 사건이 없다</Empty>
            ) : (
              <ul className="tl">
                {(events.data ?? []).map((e) => (
                  <li key={e.id}>
                    <div className="tl__ts">{kstTime(e.ts)}</div>
                    <div className="tl__rail">
                      <span className={`tl__dot tl__dot--${severityTone(e.severity)}`} />
                    </div>
                    <div className="tl__body">
                      <div className="tl__title">{EVENT_KO[e.event_type]}</div>
                      <div className="tl__meta">
                        <span className="mono">{e.event_type}</span>
                        {e.severity ? ` · 심각도 ${e.severity}` : ''}
                        {e.x !== null && e.y !== null
                          ? ` · (${e.x.toFixed(1)}, ${e.y.toFixed(1)}) m` : ''}
                      </div>
                      {Object.keys(e.payload ?? {}).length ? (
                        <div className="tl__payload">{JSON.stringify(e.payload)}</div>
                      ) : null}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </>
  )
}

function Row({ k, children }: { k: string; children: ReactNode }) {
  return (
    <tr>
      <td className="muted nowrap" style={{ width: 96 }}>{k}</td>
      <td>{children}</td>
    </tr>
  )
}
