/** `직원-계정관리` `시스템-권한관리` — admin 전용. */
import { useState } from 'react'
import { api } from '../lib/api'
import { useAuth } from '../lib/auth'
import { usePolling } from '../lib/usePolling'
import { kstDateTime, ROLE_KO } from '../lib/format'
import { Modal } from '../components/Modal'
import { useToast } from '../components/Toast'
import { Banner, Empty, Loading, Pill } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { AppUser, UserRole } from '../types'

const ROLE_WHY: Record<UserRole, string> = {
  admin: '계정 관리까지 전부',
  staff: '목적지·구역 편집, 원격 취소',
  viewer: '보기만 가능',
}

export function Users() {
  const { user: me } = useAuth()
  const toast = useToast()
  const [adding, setAdding] = useState(false)
  const [pwOpen, setPwOpen] = useState(false)
  const users = usePolling<AppUser[]>(() => api.listUsers(), [], null)

  const deactivate = async (u: AppUser) => {
    try {
      await api.deactivateUser(u.id)
      toast(`${u.display_name} 계정을 비활성화했다`)
      users.refresh()
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true)
    }
  }

  return (
    <>
      <PageHead
        title="계정 관리"
        sub="역할 위계: 관리자 > 직원 > 조회 전용"
        right={<>
          <button className="btn btn--sm" onClick={() => setPwOpen(true)}>내 비밀번호 변경</button>
          <button className="btn btn--sm btn--primary" onClick={() => setAdding(true)}>+ 계정 추가</button>
        </>}
      />

      <div className="page stack">
        {users.error ? <Banner tone="bad">{users.error}</Banner> : null}
        <div className="card">
          <div className="card__body--flush">
            {users.loading && !users.data ? <Loading /> : null}
            {users.data?.length === 0 ? <Empty icon="👤">계정이 없다</Empty> : null}
            <table className="tbl">
              <thead>
                <tr>
                  <th>이름</th>
                  <th style={{ width: 240 }}>이메일</th>
                  <th style={{ width: 190 }}>역할</th>
                  <th style={{ width: 160 }}>마지막 로그인</th>
                  <th style={{ width: 110 }} className="right" />
                </tr>
              </thead>
              <tbody>
                {(users.data ?? []).map((u) => (
                  <tr key={u.id} className={u.is_active ? '' : 'row--dim'}>
                    <td>
                      <b>{u.display_name}</b>
                      {u.id === me?.id ? <span className="muted"> · 나</span> : null}
                    </td>
                    <td className="mono" style={{ fontSize: 12 }}>{u.email}</td>
                    <td>
                      <Pill tone={u.role === 'admin' ? 'active' : u.role === 'staff' ? 'info' : 'muted'}>
                        {ROLE_KO[u.role]}
                      </Pill>
                      <div className="muted" style={{ fontSize: 11.5 }}>{ROLE_WHY[u.role]}</div>
                    </td>
                    <td className="nowrap">{kstDateTime(u.last_login_at)}</td>
                    <td className="right">
                      {u.is_active ? (
                        <button className="btn btn--sm btn--danger" disabled={u.id === me?.id}
                                onClick={() => deactivate(u)}
                                title={u.id === me?.id ? '자기 계정은 비활성화할 수 없다' : ''}>
                          비활성화
                        </button>
                      ) : <span className="muted">비활성</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <Banner tone="info">
          <span>ⓘ</span>
          <div>
            계정은 물리 삭제하지 않는다 — 과거 안내 기록이 참조한다. 비활성화만 된다.
            마지막 관리자 계정은 서버가 막는다.
          </div>
        </Banner>
      </div>

      {adding ? (
        <AddUser onClose={() => setAdding(false)}
                 onDone={() => { setAdding(false); users.refresh() }} />
      ) : null}
      {pwOpen ? <ChangePassword onClose={() => setPwOpen(false)} /> : null}
    </>
  )
}

function AddUser({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const toast = useToast()
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [pw, setPw] = useState('')
  const [role, setRole] = useState<UserRole>('viewer')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const save = async () => {
    setBusy(true); setErr(null)
    try {
      await api.createUser({ email: email.trim(), password: pw, display_name: name.trim(), role })
      toast(`${name} 계정을 만들었다`)
      onDone()
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e))
    } finally { setBusy(false) }
  }

  return (
    <Modal title="계정 추가" onClose={onClose} footer={<>
      <button className="btn" onClick={onClose}>취소</button>
      <button className="btn btn--primary" onClick={save}
              disabled={busy || !email || !name || pw.length < 8}>
        {busy ? <span className="spin" /> : null} 만들기
      </button>
    </>}>
      <div className="field">
        <label>이메일</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div className="field">
        <label>표시 이름</label>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="김복지" />
      </div>
      <div className="field">
        <label>임시 비밀번호</label>
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <span className="hint">8자 이상. 본인이 로그인한 뒤 직접 바꾸게 한다.</span>
      </div>
      <div className="field">
        <label>역할</label>
        <select value={role} onChange={(e) => setRole(e.target.value as UserRole)}>
          {(['viewer', 'staff', 'admin'] as UserRole[]).map((r) => (
            <option key={r} value={r}>{ROLE_KO[r]} — {ROLE_WHY[r]}</option>
          ))}
        </select>
      </div>
      {err ? <Banner tone="bad">{err}</Banner> : null}
    </Modal>
  )
}

function ChangePassword({ onClose }: { onClose: () => void }) {
  const toast = useToast()
  const [cur, setCur] = useState('')
  const [next, setNext] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const save = async () => {
    setBusy(true); setErr(null)
    try {
      await api.changePassword(cur, next)
      toast('비밀번호를 바꿨다')
      onClose()
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e))
    } finally { setBusy(false) }
  }

  return (
    <Modal title="내 비밀번호 변경" onClose={onClose} footer={<>
      <button className="btn" onClick={onClose}>취소</button>
      <button className="btn btn--primary" onClick={save} disabled={busy || !cur || next.length < 8}>
        {busy ? <span className="spin" /> : null} 변경
      </button>
    </>}>
      <div className="field">
        <label>현재 비밀번호</label>
        <input type="password" value={cur} onChange={(e) => setCur(e.target.value)} />
      </div>
      <div className="field">
        <label>새 비밀번호</label>
        <input type="password" value={next} onChange={(e) => setNext(e.target.value)} />
        <span className="hint">8자 이상</span>
      </div>
      {err ? <Banner tone="bad">{err}</Banner> : null}
    </Modal>
  )
}
