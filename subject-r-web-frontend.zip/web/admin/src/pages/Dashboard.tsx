/**
 * `직원-로봇상태` `직원-실시간위치` `직원-대리요청` `직원-원격취소`
 *
 * 실시간 위치는 pose_log + WebSocket 이 있어야 진짜가 된다.
 * 로그 발행 주기(Hz)가 아직 안 정해져서, 지금은 GET /robots · GET /trips 를
 * 폴링해서 "상태와 진행 중인 안내"까지만 실시간으로 보여준다.
 */
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api'
import { useAuth } from '../lib/auth'
import { useMaps, MapPicker } from '../lib/mapctx'
import { POLL_MS, usePolling } from '../lib/usePolling'
import { usePoiNames } from '../lib/usePoiNames'
import {
  meters, ROBOT_STATUS_KO, ROBOT_STATUS_TONE, REQUESTER_KO, sinceNow,
  TRIP_LIVE, TRIP_MODE_KO, TRIP_STATUS_KO, TRIP_STATUS_TONE, kstTime,
} from '../lib/format'
import { FloorMap } from '../components/FloorMap'
import { Modal } from '../components/Modal'
import { useToast } from '../components/Toast'
import { Banner, Battery, Empty, Loading, Pill, Stat } from '../components/ui'
import { LiveTag, PageHead } from '../components/Layout'
import type { Poi, Robot, Trip } from '../types'

export function Dashboard() {
  const { can } = useAuth()
  const { map, mapId, loading: mapLoading, error: mapError } = useMaps()
  const toast = useToast()
  const [proxyFor, setProxyFor] = useState<Robot | null>(null)

  const robots = usePolling<Robot[]>(() => api.listRobots(), [])
  const trips = usePolling<Trip[]>(() => api.listTrips({ limit: 30 }), [])
  // 지도·목적지·구역은 자주 안 바뀐다. 폴링하지 않고 한 번만 읽는다.
  const bundle = usePolling(
    () => (mapId ? api.bundle(mapId) : Promise.resolve(null)),
    [mapId], null,
  )

  const live = useMemo(
    () => (trips.data ?? []).filter((t) => TRIP_LIVE.includes(t.status)),
    [trips.data],
  )
  const poiName = usePoiNames(mapId)

  const today = useMemo(() => {
    const start = new Date(); start.setHours(0, 0, 0, 0)
    return (trips.data ?? []).filter((t) => new Date(t.requested_at) >= start)
  }, [trips.data])

  const cancel = async (t: Trip) => {
    try {
      await api.updateTrip(t.id, { status: 'canceled', abort_reason: '직원 원격 취소' })
      toast(`안내 #${t.id} 을(를) 취소했다`)
      trips.refresh()
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true)
    }
  }

  const busy = robots.loading || mapLoading

  return (
    <>
      <PageHead
        title="대시보드"
        sub="로봇 상태와 진행 중인 안내"
        right={<>
          <MapPicker />
          <LiveTag updatedAt={robots.updatedAt} error={robots.error} />
        </>}
      />

      <div className="page stack">
        {mapError ? <Banner tone="bad">지도를 불러오지 못했다 — {mapError}</Banner> : null}
        {robots.error ? <Banner tone="bad">{robots.error}</Banner> : null}

        <div className="grid grid--4">
          <Stat label="등록 로봇" value={robots.data?.length ?? '—'} unit="대"
                foot={`${(robots.data ?? []).filter((r) => r.status !== 'offline').length}대 온라인`} />
          <Stat label="진행 중 안내" value={live.length} unit="건"
                tone={live.length ? 'active' : undefined}
                foot={live.length ? '아래 목록에서 취소할 수 있다' : '지금은 조용하다'} />
          <Stat label="오늘 안내" value={today.length} unit="건"
                foot={`완료 ${today.filter((t) => t.status === 'completed').length}건`} />
          <Stat
            label="주의 필요"
            value={(robots.data ?? []).filter((r) => r.status === 'error' || r.status === 'estop'
              || (r.battery_pct ?? 100) <= 20).length}
            unit="대"
            tone="bad"
            foot="오류 · 비상정지 · 배터리 20% 이하"
          />
        </div>

        <div className="grid grid--main">
          <div className="card">
            <div className="card__head">
              <h3>{map ? `${map.floor}층 — ${map.name ?? `v${map.version}`}` : '지도'}</h3>
              <span className="spacer" />
              <span className="muted" style={{ fontSize: 12 }}>
                목적지 {bundle.data?.pois.length ?? 0} · 구역 {bundle.data?.zones.length ?? 0}
              </span>
            </div>
            {map && bundle.data ? (
              <FloorMap map={map} pois={bundle.data.pois} zones={bundle.data.zones} />
            ) : (
              <Loading label="지도를 불러오는 중" />
            )}
            <div style={{ padding: '0 16px 14px' }}>
              <Banner tone="warn">
                <span>◔</span>
                <div>
                  <b>로봇 위치 표시는 아직 없다.</b> <code>GET /robots</code> 응답에 좌표가 없다 —
                  <code>pose_log</code> 와 WebSocket(<code>직원-실시간위치</code> · <code>로봇-위치보고</code>)이
                  생기면 이 지도 위에 바로 올린다. 그때까지는 상태·배터리만{' '}
                  {Math.round(POLL_MS / 1000)}초마다 다시 읽는다.
                </div>
              </Banner>
            </div>
          </div>

          <div className="stack">
            <div className="card">
              <div className="card__head"><h3>로봇</h3></div>
              <div className="card__body--flush">
                {busy && !robots.data ? <Loading /> : null}
                {robots.data?.length === 0 ? <Empty icon="🤖">등록된 로봇이 없다</Empty> : null}
                {(robots.data ?? []).map((r) => (
                  <div key={r.id} style={{
                    padding: '12px 16px', borderTop: '1px solid var(--line)',
                    display: 'grid', gap: 6,
                  }}>
                    <div className="gap8">
                      <b style={{ fontSize: 14 }}>{r.name}</b>
                      <Pill tone={ROBOT_STATUS_TONE[r.status]}>{ROBOT_STATUS_KO[r.status]}</Pill>
                      <span className="spacer" style={{ marginLeft: 'auto' }} />
                      <Battery pct={r.battery_pct} />
                    </div>
                    <div className="muted" style={{ fontSize: 12 }}>
                      <span className="mono">{r.serial}</span>
                      {r.model ? ` · ${r.model}` : ''} · 최근 통신 {sinceNow(r.last_seen_at)}
                    </div>
                    {can('staff') ? (
                      <div className="gap8">
                        <button className="btn btn--sm" onClick={() => setProxyFor(r)}
                                disabled={!r.current_map_id}>
                          대신 안내 요청
                        </button>
                        {!r.current_map_id ? (
                          <span className="muted" style={{ fontSize: 11.5 }}>
                            지도가 지정되지 않아 요청할 수 없다
                          </span>
                        ) : null}
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="card__head">
                <h3>진행 중인 안내</h3>
                <Link className="btn btn--sm btn--ghost spacer" to="/trips"
                      style={{ marginLeft: 'auto' }}>전체 보기 →</Link>
              </div>
              <div className="card__body--flush">
                {live.length === 0 ? (
                  <Empty icon="✓">진행 중인 안내가 없다</Empty>
                ) : live.map((t) => (
                  <div key={t.id} style={{
                    padding: '12px 16px', borderTop: '1px solid var(--line)', display: 'grid', gap: 6,
                  }}>
                    <div className="gap8">
                      <Pill tone={TRIP_STATUS_TONE[t.status]}>{TRIP_STATUS_KO[t.status]}</Pill>
                      <b>{t.dest_poi_id ? poiName(t.dest_poi_id) : TRIP_MODE_KO[t.mode]}</b>
                      <span style={{ marginLeft: 'auto' }} className="muted">
                        {kstTime(t.started_at ?? t.requested_at)}
                      </span>
                    </div>
                    <div className="muted" style={{ fontSize: 12 }}>
                      #{t.id} · {REQUESTER_KO[t.requested_by]} 요청 · 예상 {meters(t.planned_distance_m)}
                      {t.is_simulated ? ' · 시뮬레이션' : ''}
                    </div>
                    <div className="gap8">
                      <Link className="btn btn--sm" to={`/trips/${t.id}`}>상세</Link>
                      {can('staff') ? (
                        <button className="btn btn--sm btn--danger" onClick={() => cancel(t)}>
                          원격 취소
                        </button>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {proxyFor ? (
        <ProxyRequest
          robot={proxyFor}
          pois={bundle.data?.pois ?? []}
          onClose={() => setProxyFor(null)}
          onDone={() => { setProxyFor(null); trips.refresh() }}
        />
      ) : null}
    </>
  )
}

/** `직원-대리요청` — 거동이 불편한 분 대신 직원이 안내를 시작한다. */
function ProxyRequest({
  robot, pois, onClose, onDone,
}: { robot: Robot; pois: Poi[]; onClose: () => void; onDone: () => void }) {
  const toast = useToast()
  const [dest, setDest] = useState<number | ''>('')
  const [sim, setSim] = useState(false)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async () => {
    if (dest === '') return
    setBusy(true); setErr(null)
    try {
      const t = await api.createTrip({
        robot_id: robot.id, mode: 'guide', dest_poi_id: Number(dest),
        requested_by: 'dashboard', is_simulated: sim,
      })
      toast(`안내 #${t.id} 을(를) 요청했다`)
      onDone()
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      title={`${robot.name} — 대신 안내 요청`}
      onClose={onClose}
      footer={<>
        <button className="btn" onClick={onClose}>취소</button>
        <button className="btn btn--primary" onClick={submit} disabled={busy || dest === ''}>
          {busy ? <span className="spin" /> : null} 안내 시작
        </button>
      </>}
    >
      <div className="field">
        <label>목적지</label>
        <select value={dest} onChange={(e) => setDest(e.target.value === '' ? '' : Number(e.target.value))}>
          <option value="">— 선택 —</option>
          {pois.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name_ko}{p.wheelchair_accessible ? '' : ' (휠체어 진입 불가)'}
            </option>
          ))}
        </select>
        <span className="hint">
          키오스크와 같은 <code>POST /trips</code> 를 쓰되 <code>requested_by=dashboard</code> 로 남는다.
        </span>
      </div>
      <label className="checkline">
        <input type="checkbox" checked={sim} onChange={(e) => setSim(e.target.checked)} />
        시뮬레이션으로 표시 (실제 주행 통계에서 뺀다)
      </label>
      {err ? <Banner tone="bad">{err}</Banner> : null}
    </Modal>
  )
}
