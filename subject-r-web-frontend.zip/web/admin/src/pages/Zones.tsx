/**
 * `직원-구역편집` — 편집 API가 아직 없다.
 * 읽기는 `GET /maps/{id}/bundle` 에 zones 가 들어 있어 가능하므로,
 * "지금 로봇이 무슨 구역을 물고 있는지" 는 여기서 확인할 수 있게 해뒀다.
 */
import { MapPicker, useMaps } from '../lib/mapctx'
import { usePolling } from '../lib/usePolling'
import { api } from '../lib/api'
import { FloorMap } from '../components/FloorMap'
import { Banner, Empty, Loading, NotReady, Pill } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { ZoneType } from '../types'

const ZONE_KO: Record<ZoneType, { label: string; tone: string; why: string }> = {
  keepout:      { label: '진입금지', tone: 'bad',    why: '로봇이 절대 들어가지 않는다' },
  slow:         { label: '서행',     tone: 'warn',   why: '속도 제한을 걸고 통과한다' },
  caution:      { label: '주의',     tone: 'active', why: '통과하되 감지 민감도를 올린다' },
  service_area: { label: '서비스 구역', tone: 'ok',  why: '안내를 제공하는 범위' },
}

export function Zones() {
  const { map, mapId } = useMaps()
  const bundle = usePolling(
    () => (mapId ? api.bundle(mapId) : Promise.resolve(null)), [mapId], null,
  )
  const zones = bundle.data?.zones ?? []

  return (
    <>
      <PageHead title="구역 관리" sub="진입금지 · 서행 구역" right={<MapPicker />} />
      <div className="page stack">
        <NotReady
          label="직원-구역편집"
          waiting="구역을 화면에서 그려 저장하는 API가 아직 없다. 지금은 조회만 된다. 구조가 목적지 편집과 같으므로 POST/PATCH/DELETE /zones 를 같은 방식으로 붙이면 이 화면에서 바로 그릴 수 있다."
        >
          <div className="gap8">
            <code>POST /zones</code><code>PATCH /zones/{'{id}'}</code><code>DELETE /zones/{'{id}'}</code>
          </div>
        </NotReady>

        <div className="grid grid--main">
          <div className="card">
            <div className="card__head">
              <h3>지도</h3>
              <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
                구역 {zones.length}개
              </span>
            </div>
            {map && bundle.data
              ? <FloorMap map={map} pois={bundle.data.pois} zones={zones} tall />
              : <Loading label="지도를 불러오는 중" />}
          </div>

          <div className="card">
            <div className="card__head"><h3>구역 목록</h3></div>
            <div className="card__body--flush">
              {bundle.loading && !bundle.data ? <Loading /> : null}
              {!bundle.loading && zones.length === 0 ? (
                <Empty icon="⬡">등록된 구역이 없다</Empty>
              ) : null}
              <table className="tbl">
                <tbody>
                  {zones.map((z) => {
                    const meta = ZONE_KO[z.zone_type]
                    return (
                      <tr key={z.id}>
                        <td>
                          <div style={{ fontWeight: 600 }}>{z.name}</div>
                          <div className="muted" style={{ fontSize: 11.5 }}>
                            {meta.why} · 꼭짓점 {z.polygon.length}개 · 우선순위 {z.priority}
                            {z.speed_limit_mps ? ` · 제한 ${z.speed_limit_mps} m/s` : ''}
                          </div>
                        </td>
                        <td className="right"><Pill tone={meta.tone}>{meta.label}</Pill></td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <Banner tone="info">
          <span>ⓘ</span>
          <div>
            구역은 로봇이 <code>GET /maps/{'{id}'}/bundle</code> 로 통째로 받아가 오프라인에서도 쓴다.
            구역을 고치면 <code>etag</code> 가 바뀌고, 로봇은 다음 접속 때 다시 내려받는다.
          </div>
        </Banner>
      </div>
    </>
  )
}
