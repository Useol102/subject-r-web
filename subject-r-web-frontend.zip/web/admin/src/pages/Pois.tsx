/** `직원-목적지편집` `직원-음성문구편집` */
import { useEffect, useMemo, useState } from 'react'
import { api } from '../lib/api'
import { useAuth } from '../lib/auth'
import { MapPicker, useMaps } from '../lib/mapctx'
import { usePolling } from '../lib/usePolling'
import { CATEGORY_KO, kstDateTime } from '../lib/format'
import { CATEGORY_ICON, FloorMap } from '../components/FloorMap'
import { Modal } from '../components/Modal'
import { useToast } from '../components/Toast'
import { Banner, Empty, Loading } from '../components/ui'
import { PageHead } from '../components/Layout'
import type { PoiAdmin, PoiCategory, PoiCreate } from '../types'

const CATEGORIES = Object.keys(CATEGORY_KO) as PoiCategory[]

export function Pois() {
  const { can } = useAuth()
  const { map, mapId } = useMaps()
  const toast = useToast()
  const [editing, setEditing] = useState<PoiAdmin | 'new' | null>(null)
  const [showHidden, setShowHidden] = useState(true)
  const [dragId, setDragId] = useState<number | null>(null)
  const [overId, setOverId] = useState<number | null>(null)
  const [order, setOrder] = useState<PoiAdmin[] | null>(null)
  const [saving, setSaving] = useState(false)

  const pois = usePolling<PoiAdmin[]>(
    () => (mapId ? api.listPoisAdmin(mapId, true) : Promise.resolve([])),
    [mapId], null,
  )

  // 드래그 중에는 서버 목록 대신 로컬 순서를 쓴다.
  useEffect(() => { setOrder(null) }, [pois.data])

  const rows = useMemo(() => {
    const base = order ?? pois.data ?? []
    return showHidden ? base : base.filter((p) => p.is_active)
  }, [order, pois.data, showHidden])

  const dirty = order !== null

  const move = (from: number, to: number) => {
    const base = [...(order ?? pois.data ?? [])]
    const i = base.findIndex((p) => p.id === from)
    const j = base.findIndex((p) => p.id === to)
    if (i < 0 || j < 0 || i === j) return
    const [it] = base.splice(i, 1)
    base.splice(j, 0, it)
    setOrder(base)
  }

  const saveOrder = async () => {
    if (!mapId || !order) return
    setSaving(true)
    try {
      await api.reorderPois(mapId, order.map((p, i) => ({ poi_id: p.id, display_order: i + 1 })))
      toast('표시 순서를 저장했다')
      setOrder(null)
      pois.refresh()
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true)
    } finally {
      setSaving(false)
    }
  }

  const toggleHide = async (p: PoiAdmin) => {
    try {
      if (p.is_active) {
        await api.hidePoi(p.id)
        toast(`${p.name_ko} 을(를) 숨겼다`)
      } else {
        await api.restorePoi(p.id)
        toast(`${p.name_ko} 을(를) 다시 켰다`)
      }
      pois.refresh()
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true)
    }
  }

  const readOnly = !can('staff')

  return (
    <>
      <PageHead
        title="목적지 관리"
        sub="어르신 화면의 버튼 목록이 된다. 위에 있을수록 먼저 보인다."
        right={<>
          <MapPicker />
          {dirty ? (
            <>
              <button className="btn btn--sm" onClick={() => setOrder(null)}>되돌리기</button>
              <button className="btn btn--sm btn--primary" onClick={saveOrder} disabled={saving}>
                {saving ? <span className="spin" /> : null} 순서 저장
              </button>
            </>
          ) : null}
          {!readOnly ? (
            <button className="btn btn--sm btn--primary" onClick={() => setEditing('new')}>
              + 목적지 추가
            </button>
          ) : null}
        </>}
      />

      <div className="page stack">
        {readOnly ? (
          <Banner tone="warn">
            <span>🔒</span>
            <div>조회 전용 계정이다. 수정하려면 <b>직원(staff)</b> 이상 권한이 필요하다.</div>
          </Banner>
        ) : null}
        {pois.error ? <Banner tone="bad">{pois.error}</Banner> : null}

        <div className="grid grid--wide">
          <div className="card">
            <div className="card__head">
              <h3>목적지 {rows.length}개</h3>
              <span className="spacer" style={{ marginLeft: 'auto' }} />
              <label className="checkline">
                <input type="checkbox" checked={showHidden}
                       onChange={(e) => setShowHidden(e.target.checked)} />
                숨긴 것도 보기
              </label>
            </div>
            <div className="card__body--flush">
              {pois.loading && !pois.data ? <Loading /> : null}
              {!pois.loading && rows.length === 0 ? (
                <Empty icon="📍">등록된 목적지가 없다</Empty>
              ) : (
                <div className="tbl-wrap">
                  <table className="tbl">
                    <thead>
                      <tr>
                        <th style={{ width: 30 }} />
                        <th style={{ width: 34 }} />
                        <th style={{ minWidth: 160 }}>이름</th>
                        <th style={{ width: 86 }} className="nowrap">분류</th>
                        <th style={{ width: 104 }} className="right nowrap">좌표 (m)</th>
                        <th style={{ width: 62 }} className="nowrap">휠체어</th>
                        <th>음성 안내 문구</th>
                        <th style={{ width: 106 }} />
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((p) => (
                        <tr key={p.id}
                            className={[
                              !p.is_active ? 'row--dim' : '',
                              dragId === p.id ? 'dragging' : '',
                              overId === p.id ? 'dropbefore' : '',
                            ].join(' ').trim()}
                            draggable={!readOnly}
                            onDragStart={() => setDragId(p.id)}
                            onDragOver={(e) => { e.preventDefault(); setOverId(p.id) }}
                            onDragLeave={() => setOverId((v) => (v === p.id ? null : v))}
                            onDrop={(e) => {
                              e.preventDefault()
                              if (dragId !== null) move(dragId, p.id)
                              setDragId(null); setOverId(null)
                            }}
                            onDragEnd={() => { setDragId(null); setOverId(null) }}>
                          <td className="drag">{readOnly ? '' : '⠿'}</td>
                          <td style={{ fontSize: 17 }}>{CATEGORY_ICON[p.category]}</td>
                          <td>
                            <div style={{ fontWeight: 600 }}>{p.name_ko}</div>
                            <div className="muted" style={{ fontSize: 11.5 }}>
                              <span className="mono">{p.code}</span>
                              {p.name_short ? ` · 버튼 “${p.name_short}”` : ''}
                              {!p.is_selectable ? ' · 목록 비노출' : ''}
                              {!p.is_active ? ' · 숨김' : ''}
                            </div>
                          </td>
                          <td className="nowrap">{CATEGORY_KO[p.category]}</td>
                          <td className="num nowrap">{p.x.toFixed(1)}, {p.y.toFixed(1)}</td>
                          <td>{p.wheelchair_accessible ? '가능' : <span style={{ color: 'var(--bad)' }}>불가</span>}</td>
                          <td className="muted" style={{ fontSize: 12 }}>
                            {p.voice_script
                              ? <>“{p.voice_script}”</>
                              : <span style={{ color: 'var(--warn)' }}>없음 — 도착 안내를 못 한다</span>}
                          </td>
                          <td className="right nowrap">
                            {!readOnly ? (
                              <div style={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
                                <button className="btn btn--sm btn--ghost"
                                        onClick={() => setEditing(p)}>수정</button>
                                <button className="btn btn--sm btn--ghost"
                                        onClick={() => toggleHide(p)}>
                                  {p.is_active ? '숨김' : '복구'}
                                </button>
                              </div>
                            ) : null}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          <div className="card">
            <div className="card__head"><h3>지도에서 보기</h3></div>
            {map ? (
              <FloorMap map={map} pois={rows} showLegend={false} />
            ) : <Loading label="지도를 불러오는 중" />}
            <div style={{ padding: 14 }}>
              <Banner tone="info">
                <span>ⓘ</span>
                <div>
                  목록 순서가 어르신 화면의 버튼 순서다. 화면에는 한 번에 6~8개만 들어가니
                  <b> 자주 쓰는 곳을 위로</b> 올려두는 편이 좋다.
                </div>
              </Banner>
            </div>
          </div>
        </div>
      </div>

      {editing && mapId ? (
        <PoiEditor
          mapId={mapId}
          poi={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); pois.refresh() }}
        />
      ) : null}
    </>
  )
}

function PoiEditor({
  mapId, poi, onClose, onSaved,
}: { mapId: number; poi: PoiAdmin | null; onClose: () => void; onSaved: () => void }) {
  const { map } = useMaps()
  const toast = useToast()
  const [f, setF] = useState<PoiCreate>({
    map_id: mapId,
    code: poi?.code ?? '',
    name_ko: poi?.name_ko ?? '',
    name_short: poi?.name_short ?? '',
    category: poi?.category ?? 'other',
    x: poi?.x ?? 0,
    y: poi?.y ?? 0,
    approach_yaw: poi?.approach_yaw ?? null,
    voice_script: poi?.voice_script ?? '',
    wheelchair_accessible: poi?.wheelchair_accessible ?? true,
    is_selectable: poi?.is_selectable ?? true,
    display_order: poi?.display_order ?? 0,
  })
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const set = <K extends keyof PoiCreate>(k: K, v: PoiCreate[K]) =>
    setF((s) => ({ ...s, [k]: v }))

  const save = async () => {
    setBusy(true); setErr(null)
    try {
      const body = {
        ...f,
        name_short: f.name_short?.trim() || null,
        voice_script: f.voice_script?.trim() || null,
      }
      if (poi) {
        const { map_id: _mapId, ...patch } = body
        await api.updatePoi(poi.id, patch)
        toast(`${body.name_ko} 을(를) 수정했다`)
      } else {
        await api.createPoi(body)
        toast(`${body.name_ko} 을(를) 추가했다`)
      }
      onSaved()
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      wide
      title={poi ? `목적지 수정 — ${poi.name_ko}` : '목적지 추가'}
      onClose={onClose}
      footer={<>
        <button className="btn" onClick={onClose}>취소</button>
        <button className="btn btn--primary" onClick={save}
                disabled={busy || !f.code.trim() || !f.name_ko.trim()}>
          {busy ? <span className="spin" /> : null} 저장
        </button>
      </>}
    >
      <div className="grid grid--2">
        <div className="field">
          <label>코드 <span className="muted">(로봇·API가 쓰는 식별자)</span></label>
          <input value={f.code} onChange={(e) => set('code', e.target.value.toUpperCase())}
                 placeholder="RESTROOM_1F" className="mono" />
        </div>
        <div className="field">
          <label>분류</label>
          <select value={f.category} onChange={(e) => set('category', e.target.value as PoiCategory)}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{CATEGORY_ICON[c]} {CATEGORY_KO[c]}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>이름</label>
          <input value={f.name_ko} onChange={(e) => set('name_ko', e.target.value)}
                 placeholder="1층 화장실" />
        </div>
        <div className="field">
          <label>버튼에 쓸 짧은 이름</label>
          <input value={f.name_short ?? ''} onChange={(e) => set('name_short', e.target.value)}
                 placeholder="화장실" />
          <span className="hint">비워두면 위의 이름을 그대로 쓴다. 7인치 화면이라 4~5자가 좋다.</span>
        </div>
      </div>

      <div className="field">
        <label>음성 안내 문구 <span className="muted">(도착했을 때 읽어준다)</span></label>
        <textarea value={f.voice_script ?? ''} onChange={(e) => set('voice_script', e.target.value)}
                  placeholder="화장실 앞에 도착했습니다." />
        <span className="hint">
          짧은 평서문으로. “경로 계획 실패” 같은 기계 용어는 쓰지 않는다.
        </span>
      </div>

      <div className="grid grid--3">
        <div className="field">
          <label>x (m)</label>
          <input type="number" step="0.1" value={f.x}
                 onChange={(e) => set('x', Number(e.target.value))} />
        </div>
        <div className="field">
          <label>y (m)</label>
          <input type="number" step="0.1" value={f.y}
                 onChange={(e) => set('y', Number(e.target.value))} />
        </div>
        <div className="field">
          <label>접근 방향 yaw (rad)</label>
          <input type="number" step="0.01" value={f.approach_yaw ?? ''}
                 onChange={(e) => set('approach_yaw',
                   e.target.value === '' ? null : Number(e.target.value))}
                 placeholder="비워두면 없음" />
        </div>
      </div>

      {map ? (
        <div>
          <div className="hint" style={{ marginBottom: 6 }}>
            지도를 클릭하면 좌표가 채워진다. 지도 밖 좌표는 서버가 400으로 거절한다.
          </div>
          <FloorMap
            map={map}
            pois={poi ? [{ ...poi, x: f.x, y: f.y, category: f.category }] : []}
            points={[{ x: f.x, y: f.y, tone: 'info', label: f.name_ko || '새 목적지' }]}
            onPick={(x, y) => { set('x', x); set('y', y) }}
            showLegend={false}
          />
        </div>
      ) : null}

      <div className="grid grid--2">
        <label className="checkline">
          <input type="checkbox" checked={f.wheelchair_accessible}
                 onChange={(e) => set('wheelchair_accessible', e.target.checked)} />
          휠체어로 갈 수 있다
        </label>
        <label className="checkline">
          <input type="checkbox" checked={f.is_selectable}
                 onChange={(e) => set('is_selectable', e.target.checked)} />
          어르신 화면 목록에 띄운다
        </label>
      </div>

      {poi ? (
        <div className="muted" style={{ fontSize: 11.5 }}>
          만든 날 {kstDateTime(poi.created_at)} · 마지막 수정 {kstDateTime(poi.updated_at)}
        </div>
      ) : null}

      {err ? <Banner tone="bad">{err}</Banner> : null}
    </Modal>
  )
}
