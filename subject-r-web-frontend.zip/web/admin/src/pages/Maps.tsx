/**
 * `직원-지도관리` — 업로드·활성 전환 API가 아직 없다.
 * 목록 조회(`GET /maps`)는 되므로 어떤 버전이 있고 무엇이 활성인지까지는 보여준다.
 */
import { useMaps } from '../lib/mapctx'
import { FloorMap } from '../components/FloorMap'
import { usePolling } from '../lib/usePolling'
import { api } from '../lib/api'
import { Banner, Empty, Loading, NotReady, Pill } from '../components/ui'
import { PageHead } from '../components/Layout'

export function Maps() {
  const { maps, mapId, setMapId, map, loading, error } = useMaps()
  const bundle = usePolling(
    () => (mapId ? api.bundle(mapId) : Promise.resolve(null)), [mapId], null,
  )

  return (
    <>
      <PageHead title="지도 관리" sub="SLAM 지도 버전" />
      <div className="page stack">
        <NotReady
          label="직원-지도관리"
          waiting="새 SLAM 지도(.pgm/.yaml)를 올리고 활성 버전을 바꾸는 API가 아직 없다. 이미지·rosbag 같은 큰 파일은 DB에 넣지 않기로 했으므로, 파일 저장소를 먼저 정해야 만들 수 있다 (경로 + sha256 만 DB에 남긴다)."
        >
          <div className="gap8">
            <code>POST /maps</code><code>POST /maps/{'{id}'}/activate</code>
          </div>
        </NotReady>

        {error ? <Banner tone="bad">{error}</Banner> : null}
        {loading ? <Loading /> : null}

        <div className="grid grid--main">
          <div className="card">
            <div className="card__head"><h3>버전 목록</h3></div>
            <div className="card__body--flush">
              {maps.length === 0 && !loading ? <Empty icon="🗺">등록된 지도가 없다</Empty> : null}
              <table className="tbl">
                <thead>
                  <tr>
                    <th style={{ width: 44 }}>층</th>
                    <th>이름</th>
                    <th style={{ width: 58 }} className="right">버전</th>
                    <th style={{ width: 130 }} className="right">크기</th>
                    <th style={{ width: 118 }} className="right">해상도 · 원점</th>
                    <th style={{ width: 74 }} />
                  </tr>
                </thead>
                <tbody>
                  {maps.map((m) => (
                    <tr key={m.id} className="row--link" onClick={() => setMapId(m.id)}
                        style={m.id === mapId
                          ? { outline: '2px solid var(--brand)', outlineOffset: -2 } : undefined}>
                      <td className="mono">{m.floor}F</td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{m.name ?? `(이름 없음)`}</div>
                        <div className="muted mono" style={{ fontSize: 11 }}>{m.pgm_uri}</div>
                      </td>
                      <td className="num">v{m.version}</td>
                      <td className="num">
                        {m.width_px && m.height_px
                          ? `${(m.width_px * m.resolution_m).toFixed(1)} × ${(m.height_px * m.resolution_m).toFixed(1)} m`
                          : '—'}
                      </td>
                      <td className="num">
                        {m.resolution_m} m/px<br />
                        <span className="muted">({m.origin_x}, {m.origin_y})</span>
                      </td>
                      <td className="right">
                        {m.is_active ? <Pill tone="ok">활성</Pill> : <span className="muted">보관</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="card">
            <div className="card__head">
              <h3>미리보기</h3>
              <span className="muted" style={{ marginLeft: 'auto', fontSize: 12 }}>
                {bundle.data ? `etag ${bundle.data.etag.slice(0, 10)}…` : ''}
              </span>
            </div>
            {map && bundle.data
              ? <FloorMap map={map} pois={bundle.data.pois} zones={bundle.data.zones} tall />
              : <Loading label="지도를 불러오는 중" />}
          </div>
        </div>

        <Banner tone="info">
          <span>ⓘ</span>
          <div>
            지도 이미지는 <code>pgm_uri</code> 가 <code>s3://</code> 라 브라우저가 직접 못 읽는다.
            PNG 로 변환해 서빙하고 <code>VITE_MAP_IMAGE_BASE</code> 를 설정하면
            모든 지도 화면의 배경으로 깔린다. 지금은 격자만 그린다.
          </div>
        </Banner>
      </div>
    </>
  )
}
