/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE?: string
  readonly VITE_MAP_ID?: string
  readonly VITE_POLL_MS?: string
  readonly VITE_MAP_IMAGE_BASE?: string
  /** 'on' 이면 백엔드 없이 가짜 API로 돈다 (데모 전용) */
  readonly VITE_MOCK?: string
}
interface ImportMeta { readonly env: ImportMetaEnv }
