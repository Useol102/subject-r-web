import type { JSX } from 'react'
import {
  BrowserRouter, MemoryRouter, Navigate, Route, Routes,
} from 'react-router-dom'
import { AuthProvider, useAuth } from './lib/auth'
import { MapProvider } from './lib/mapctx'
import { ToastHost } from './components/Toast'
import { Layout } from './components/Layout'
import { Login } from './pages/Login'
import { Dashboard } from './pages/Dashboard'
import { Trips } from './pages/Trips'
import { TripDetail } from './pages/TripDetail'
import { Pois } from './pages/Pois'
import { Stats } from './pages/Stats'
import { Heatmap } from './pages/Heatmap'
import { Zones } from './pages/Zones'
import { Maps } from './pages/Maps'
import { Users } from './pages/Users'
import type { UserRole } from './types'

// 데모 빌드는 about:srcdoc 같은 샌드박스에서 열릴 수 있다.
// 그런 곳에는 주소가 없어서 history/hash 라우터가 URL 파싱에서 죽는다. 메모리 라우터로 뜬다.
const Router = import.meta.env.VITE_MOCK === 'on' ? MemoryRouter : BrowserRouter

/** 권한이 모자라면 대시보드로 되돌린다. 서버도 403으로 막지만 화면에서 먼저 막는다. */
function Guard({ need, children }: { need: UserRole; children: JSX.Element }) {
  const { can } = useAuth()
  return can(need) ? children : <Navigate to="/" replace />
}

function Shell() {
  const { user, ready } = useAuth()

  if (!ready) {
    return <div className="center-load"><span className="spin" />불러오는 중</div>
  }
  if (!user) return <Login />

  return (
    <MapProvider>
      <Router>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/trips" element={<Trips />} />
            <Route path="/trips/:id" element={<TripDetail />} />
            <Route path="/stats" element={<Stats />} />
            <Route path="/heatmap" element={<Heatmap />} />
            <Route path="/pois" element={<Pois />} />
            <Route path="/zones" element={<Guard need="staff"><Zones /></Guard>} />
            <Route path="/maps" element={<Guard need="staff"><Maps /></Guard>} />
            <Route path="/users" element={<Guard need="admin"><Users /></Guard>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </Router>
    </MapProvider>
  )
}

export default function App() {
  return (
    <ToastHost>
      <AuthProvider>
        <Shell />
      </AuthProvider>
    </ToastHost>
  )
}
