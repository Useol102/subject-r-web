import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'

async function boot() {
  // 데모 빌드(VITE_MOCK=on)에서만 가짜 API를 붙인다.
  // 일반 빌드에서는 이 청크가 아예 만들어지지 않는다.
  if (import.meta.env.VITE_MOCK === 'on') {
    const { installMock } = await import('./demo/mock')
    installMock()
  }
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
}

void boot()
