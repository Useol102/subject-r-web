import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 관리자 대시보드는 5173.  키오스크(5174)와 포트를 나눠 쓴다.
// API의 CORS_ORIGINS 에 두 주소가 모두 들어 있어야 한다.
//
// VITE_MOCK=on 으로 빌드하면 백엔드 없이 도는 데모 번들이 된다
// (`npm run build:demo`). 이때는 파일 하나로 합쳐야 하므로
// 동적 import 와 이미지를 전부 인라인한다.
const demo = process.env.VITE_MOCK === 'on'

export default defineConfig({
  plugins: [react()],
  base: demo ? './' : '/',
  server: { port: 5173, host: true },
  preview: { port: 5173 },
  build: {
    assetsInlineLimit: demo ? 1024 * 1024 : 4096,
    cssCodeSplit: !demo,
    rollupOptions: { output: { inlineDynamicImports: demo } },
  },
})
